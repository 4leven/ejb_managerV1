import { FormEvent, useEffect, useMemo, useRef, useState } from "react";
import {
  Download,
  FileText,
  MessageCircle,
  Paperclip,
  Search,
  Send,
  Smile,
} from "lucide-react";
import {
  fetchConversations,
  fetchMessages,
  saveMessageStatus,
  sendMessage,
} from "../api/iniciativas";

type Conversation = {
  id: string;
  nombres: string;
  apellidos: string;
  fotoPerfil?: string | null;
  cargo: string;
  estadoMensaje: string;
  area: { nombre: string; colorHex: string };
  lastMessage?: { contenido: string; createdAt: string } | null;
  unread: number;
};
type Message = {
  id: string;
  remitenteId: string;
  destinatarioId: string;
  contenido: string;
  tipo: "Texto" | "Documento" | "Sticker";
  archivoNombre?: string;
  archivoMime?: string;
  archivoData?: string;
  createdAt: string;
};
const initials = (v: string) =>
  v
    .split(" ")
    .map((x) => x[0])
    .join("")
    .slice(0, 2);
const statusOptions = [
  { value: "Disponible", label: "Disponible" },
  { value: "Break", label: "Break" },
  { value: "Ausente", label: "Ausente" },
  { value: "Ocupado", label: "Ocupado" },
  { value: "No_molestar", label: "No molestar" },
];
const statusLabel = (value: string) => statusOptions.find(option => option.value === value)?.label ?? "Disponible";
export default function Messages({ currentUserId, currentStatus, onStatusChange }: { currentUserId: string; currentStatus: string; onStatusChange: (status: string) => void }) {
  const [contacts, setContacts] = useState<Conversation[]>([]),
    [active, setActive] = useState<Conversation | null>(null),
    [messages, setMessages] = useState<Message[]>([]),
    [query, setQuery] = useState(""),
    [draft,setDraft]=useState(""),
    [stickersOpen, setStickersOpen] = useState(false);
  const messagesBox=useRef<HTMLDivElement|null>(null),messageInput=useRef<HTMLInputElement|null>(null);
  const loadContacts = () =>
    fetchConversations().then((rows: Conversation[]) => {
      setContacts(rows);
      setActive((activeContact) => activeContact ? rows.find(row => row.id === activeContact.id) ?? null : rows[0] ?? null);
    });
  useEffect(() => {
    loadContacts();
    const timer = setInterval(loadContacts, 5000);
    return () => clearInterval(timer);
  }, []);
  useEffect(() => {
    if (!active) return;
    const load = () => fetchMessages(active.id).then(setMessages);
    load();
    const timer = setInterval(load, 4000);
    return () => clearInterval(timer);
  }, [active?.id]);
  useEffect(()=>{const box=messagesBox.current;if(box)box.scrollTo({top:box.scrollHeight,behavior:"smooth"})},[messages]);
  const filtered = useMemo(
    () =>
      contacts.filter((c) =>
        `${c.nombres} ${c.apellidos}`
          .toLowerCase()
          .includes(query.toLowerCase()),
      ),
    [contacts, query],
  );
  const submit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!active) return;
    if (!draft.trim()) return;
    const row = await sendMessage(active.id, draft);
    setMessages((v) => [...v, row]);
    setDraft("");
  };
  const sendSticker = (sticker: string) => {
    setDraft((value)=>`${value}${sticker}`);
    setStickersOpen(false);
    requestAnimationFrame(()=>messageInput.current?.focus());
  };
  const sendFile = (input: HTMLInputElement) => {
    const file = input.files?.[0];
    if (!file || !active) return;
    if (file.size > 2000000)
      return alert("El documento debe pesar menos de 2 MB");
    const reader = new FileReader();
    reader.onload = async () => {
      const row = await sendMessage(active.id, {
        contenido: file.name,
        tipo: "Documento",
        archivoNombre: file.name,
        archivoMime: file.type || "application/octet-stream",
        archivoData: String(reader.result),
      });
      setMessages((v) => [...v, row]);
      input.value = "";
    };
    reader.readAsDataURL(file);
  };
  return (
    <div className="messenger">
      <aside className="conversation-list">
        <label className="my-message-status">
          <span>Mi estado</span>
          <div data-status={currentStatus}>
            <i />
            <select value={currentStatus} onChange={async event => {
              const nextStatus = event.target.value;
              await saveMessageStatus(nextStatus);
              onStatusChange(nextStatus);
            }}>
              {statusOptions.map(option => <option key={option.value} value={option.value}>{option.label}</option>)}
            </select>
          </div>
        </label>
        <div className="message-search">
          <Search />
          <input
            placeholder="Buscar compañero"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
        </div>
        {filtered.map((c) => (
          <button
            key={c.id}
            className={active?.id === c.id ? "active" : ""}
            onClick={() => setActive(c)}
          >
            {c.fotoPerfil ? (
              <img src={c.fotoPerfil} />
            ) : (
              <div style={{ background: c.area.colorHex }}>
                {initials(`${c.nombres} ${c.apellidos}`)}
              </div>
            )}
            <p>
              <b>
                {c.nombres} {c.apellidos}
              </b>
              <span className="contact-status" data-status={c.estadoMensaje}><i />{statusLabel(c.estadoMensaje)}</span>
              <small>
                {c.lastMessage?.contenido ?? `${c.cargo} · ${c.area.nombre}`}
              </small>
            </p>
            {c.unread > 0 && <span>{c.unread}</span>}
          </button>
        ))}
        {!filtered.length && (
          <div className="no-contacts">No hay compañeros registrados.</div>
        )}
      </aside>
      <section className="chat-panel">
        {active ? (
          <>
            <header>
              <div style={{ background: active.area.colorHex }}>
                {initials(`${active.nombres} ${active.apellidos}`)}
              </div>
              <p>
                <b>
                  {active.nombres} {active.apellidos}
                </b>
                <span className="contact-status" data-status={active.estadoMensaje}><i />{statusLabel(active.estadoMensaje)}</span>
                <small>
                  {active.cargo} · {active.area.nombre}
                </small>
              </p>
            </header>
            <div className="messages" ref={messagesBox}>
              {messages.map((m) => (
                <article
                  key={m.id}
                  className={m.remitenteId === currentUserId ? "mine" : ""}
                >
                  {m.tipo === "Sticker" ? (
                    <div className="sticker-message">{m.contenido}</div>
                  ) : m.tipo === "Documento" ? (
                    <a
                      className="document-message"
                      href={m.archivoData}
                      download={m.archivoNombre}
                    >
                      <FileText />
                      <span>
                        <b>{m.archivoNombre}</b>
                        <small>Documento adjunto</small>
                      </span>
                      <Download />
                    </a>
                  ) : (
                    <p>{m.contenido}</p>
                  )}
                  <small>
                    {new Date(m.createdAt).toLocaleTimeString([], {
                      hour: "2-digit",
                      minute: "2-digit",
                    })}
                  </small>
                </article>
              ))}
              {!messages.length && (
                <div className="start-chat">
                  <MessageCircle />
                  <b>Inicia la conversación</b>
                  <span>Los mensajes quedan guardados de forma privada.</span>
                </div>
              )}
            </div>
            <form onSubmit={submit}>
              <label className="chat-tool" title="Adjuntar documento">
                <Paperclip />
                <input
                  type="file"
                  onChange={(e) => sendFile(e.currentTarget)}
                />
              </label>
              <button
                type="button"
                className="chat-tool"
                onClick={() => setStickersOpen((v) => !v)}
                title="Stickers"
              >
                <Smile />
              </button>
              {stickersOpen && (
                <div className="sticker-picker">
                  {[
                    "👍",
                    "🎉",
                    "🚀",
                    "✅",
                    "👏",
                    "💡",
                    "🔥",
                    "💪",
                    "⭐",
                    "😊",
                    "🤝",
                    "📌",
                  ].map((s) => (
                    <button
                      type="button"
                      key={s}
                      onClick={() => sendSticker(s)}
                    >
                      {s}
                    </button>
                  ))}
                </div>
              )}
              <input
                ref={messageInput}
                name="message"
                autoComplete="off"
                placeholder="Escribe un mensaje..."
                value={draft}
                onChange={(e)=>setDraft(e.target.value)}
              />
              <button>
                <Send />
              </button>
            </form>
          </>
        ) : (
          <div className="start-chat">
            <MessageCircle />
            <b>Mensajes EJB</b>
            <span>Selecciona un compañero para conversar.</span>
          </div>
        )}
      </section>
    </div>
  );
}
