import { NextFunction, Request, Response } from "express";
import { z } from "zod";
import { prisma } from "../config/db.js";
const tipoSchema=z.enum(["grupo","canal","firma","encuesta"]),include={creador:{select:{id:true,nombres:true,apellidos:true,fotoPerfil:true,area:true}}} as const;
export async function listar(req:Request,res:Response,next:NextFunction){try{const tipo=tipoSchema.parse(req.params.tipo);res.json(await prisma.registroPortal.findMany({where:{tipo},include,orderBy:{createdAt:"desc"}}))}catch(e){next(e)}}
export async function crear(req:Request,res:Response,next:NextFunction){try{const tipo=tipoSchema.parse(req.params.tipo),datos=z.record(z.string(),z.unknown()).parse(req.body);res.status(201).json(await prisma.registroPortal.create({data:{tipo,datos:datos as any,creadorId:req.userId!},include}))}catch(e){next(e)}}
export async function actualizar(req:Request,res:Response,next:NextFunction){try{const row=await prisma.registroPortal.findUniqueOrThrow({where:{id:String(req.params.id)}}),datos=z.record(z.string(),z.unknown()).parse(req.body);if(row.tipo==="firma"&&row.creadorId!==req.userId)throw new Error("Solo el propietario puede firmar este documento");res.json(await prisma.registroPortal.update({where:{id:row.id},data:{datos:datos as any},include}))}catch(e){next(e)}}
