import { StrictMode } from 'react'; import { createRoot } from 'react-dom/client'; import App from './App'; import {uiAlert} from './utils/dialog'; import './styles.css'; import './enhancements.css'; import './refinements.css';
window.alert=(message?:any)=>{void uiAlert('EJB MANAGER',String(message??''))};
createRoot(document.getElementById('root')!).render(<StrictMode><App/></StrictMode>);
