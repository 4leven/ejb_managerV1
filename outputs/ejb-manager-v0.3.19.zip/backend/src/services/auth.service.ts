import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import crypto from "node:crypto";
import { Cargo, Rol } from "@prisma/client";
import { prisma } from "../config/db.js";

const secret = process.env.JWT_SECRET ?? "dev-only-secret";
const publicUser = (usuario: {
  id: string;
  nombres: string;
  apellidos: string;
  email: string;
  cargo: Cargo;
  rol: Rol;
  portalColor: string;
  darkMode: boolean;
  fotoPerfil: string | null;
  estadoMensaje: string;
  isSuperAdmin: boolean;
  area: { id: string; nombre: string; colorHex: string };
}) => ({
  id: usuario.id,
  nombres: usuario.nombres,
  apellidos: usuario.apellidos,
  nombreCompleto: `${usuario.nombres} ${usuario.apellidos}`,
  email: usuario.email,
  cargo: usuario.cargo,
  rol: usuario.rol,
  portalColor: usuario.portalColor,
  darkMode: usuario.darkMode,
  fotoPerfil: usuario.fotoPerfil,
  estadoMensaje: usuario.estadoMensaje,
  isSuperAdmin: usuario.isSuperAdmin,
  area: usuario.area,
});
const token = (id: string) =>
  jwt.sign({ sub: id }, secret, { expiresIn: "8h" });

export const authService = {
  async register(data: {
    nombres: string;
    apellidos: string;
    email: string;
    password: string;
    areaId: string;
    cargo: Cargo;
  }) {
    const exists = await prisma.usuario.findUnique({
      where: { email: data.email.toLowerCase() },
    });
    if (exists) throw new Error("El correo ya está registrado");
    const passwordHash = await bcrypt.hash(data.password, 12);
    const usuario = await prisma.usuario.create({
      data: {
        nombres: data.nombres.trim(),
        apellidos: data.apellidos.trim(),
        email: data.email.toLowerCase(),
        passwordHash,
        areaId: data.areaId,
        cargo: data.cargo,
        rol: data.cargo === Cargo.Gerente ? Rol.Comite : Rol.Usuario,
      },
      include: { area: true },
    });
    return { token: token(usuario.id), usuario: publicUser(usuario) };
  },
  async login(email: string, password: string) {
    const usuario = await prisma.usuario.findUnique({
      where: { email: email.toLowerCase() },
      include: { area: true },
    });
    if (!usuario || !(await bcrypt.compare(password, usuario.passwordHash)))
      throw new Error("Correo o contraseña incorrectos");
    return { token: token(usuario.id), usuario: publicUser(usuario) };
  },
  async me(id: string) {
    const usuario = await prisma.usuario.findUniqueOrThrow({
      where: { id },
      include: { area: true },
    });
    return publicUser(usuario);
  },
  async forgot(email: string) {
    const usuario = await prisma.usuario.findUnique({
      where: { email: email.toLowerCase() },
    });
    if (!usuario) return { ok: true };
    const raw = crypto.randomBytes(32).toString("hex"),
      hash = crypto.createHash("sha256").update(raw).digest("hex");
    await prisma.usuario.update({
      where: { id: usuario.id },
      data: {
        resetTokenHash: hash,
        resetExpires: new Date(Date.now() + 30 * 60 * 1000),
      },
    });
    return {
      ok: true,
      ...(process.env.NODE_ENV === "production"
        ? {}
        : { developmentToken: raw }),
    };
  },
  async reset(tokenValue: string, password: string) {
    const hash = crypto.createHash("sha256").update(tokenValue).digest("hex");
    const usuario = await prisma.usuario.findFirst({
      where: { resetTokenHash: hash, resetExpires: { gt: new Date() } },
    });
    if (!usuario) throw new Error("El enlace es inválido o venció");
    await prisma.usuario.update({
      where: { id: usuario.id },
      data: {
        passwordHash: await bcrypt.hash(password, 12),
        resetTokenHash: null,
        resetExpires: null,
      },
    });
    return { ok: true };
  },
};
