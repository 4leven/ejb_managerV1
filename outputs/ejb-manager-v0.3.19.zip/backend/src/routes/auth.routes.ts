import { Router } from 'express';
import { forgot,login, me, register,reset } from '../controllers/auth.controller.js';
import { requireAuth } from '../middlewares/auth.js';
export const authRoutes=Router().post('/registro',register).post('/login',login).post('/olvide-password',forgot).post('/restablecer-password',reset).get('/me',requireAuth,me);
