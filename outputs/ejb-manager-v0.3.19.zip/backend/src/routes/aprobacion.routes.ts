import { Router } from 'express';import { pending,requestChange,resolve } from '../controllers/aprobacion.controller.js';
export const aprobacionRoutes=Router().get('/',pending).post('/',requestChange).post('/:id/resolver',resolve);
