import { Router } from 'express';import { conversations,send,thread } from '../controllers/mensaje.controller.js';
export const mensajeRoutes=Router().get('/conversaciones',conversations).get('/:userId',thread).post('/:userId',send);
