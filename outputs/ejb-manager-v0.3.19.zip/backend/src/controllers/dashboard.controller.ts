import { NextFunction, Request, Response } from 'express';
import { prisma } from '../config/db.js';

export async function summary(_req:Request,res:Response,next:NextFunction){
  try {
    const [total,enDesarrollo,average] = await Promise.all([
      prisma.iniciativa.count(),
      prisma.iniciativa.count({where:{estado:'En_desarrollo'}}),
      prisma.iniciativa.aggregate({_avg:{impacto:true}})
    ]);
    res.json({total,enDesarrollo,impactoPromedio:Number(average._avg.impacto??0)});
  } catch(error){ next(error); }
}
