import { NextFunction, Request, Response } from "express";
import { z } from "zod";
import { prisma } from "../config/db.js";

const estados = ["Solicitado", "Pendiente", "En revisión", "En curso", "Aprobado", "Entregado", "Desaprobado", "Rechazado"] as const;
const reqSchema = z.object({ titulo: z.string().min(2).max(180), descripcion: z.string().max(800).optional(), cantidad: z.number().int().min(1).max(9999), prioridad: z.enum(["Baja", "Normal", "Alta", "Urgente"]), estado: z.enum(estados), fechaNecesaria: z.string().optional() });
const include = { area: true, usuario: { select: { id: true, nombres: true, apellidos: true } } } as const;

export async function requirements(req: Request, res: Response, next: NextFunction) { try { const u = await prisma.usuario.findUniqueOrThrow({ where: { id: req.userId! }, include: { area: true } }); const canManage = u.isSuperAdmin || u.area.nombre === "Administración"; res.json(await prisma.requerimiento.findMany({ where: canManage ? {} : { areaId: u.areaId }, include, orderBy: { createdAt: "desc" } })); } catch (e) { next(e); } }
export async function createRequirement(req: Request, res: Response, next: NextFunction) { try { const d = reqSchema.parse(req.body), u = await prisma.usuario.findUniqueOrThrow({ where: { id: req.userId! } }); res.status(201).json(await prisma.requerimiento.create({ data: { ...d, fechaNecesaria: d.fechaNecesaria ? new Date(d.fechaNecesaria) : undefined, areaId: u.areaId, usuarioId: u.id }, include })); } catch (e) { next(e); } }

export async function updateRequirement(req: Request, res: Response, next: NextFunction) {
  try {
    const d = reqSchema.partial().parse(req.body), u = await prisma.usuario.findUniqueOrThrow({ where: { id: req.userId! }, include: { area: true } }), row = await prisma.requerimiento.findUniqueOrThrow({ where: { id: String(req.params.id) } });
    const owner = row.usuarioId === u.id, administration = u.area.nombre === "Administración";
    if (!u.isSuperAdmin && !owner && !administration) throw new Error("No tienes permiso para editar este requerimiento");
    const data = !u.isSuperAdmin && !owner ? { estado: d.estado } : { ...d, fechaNecesaria: d.fechaNecesaria ? new Date(d.fechaNecesaria) : undefined };
    res.json(await prisma.requerimiento.update({ where: { id: row.id }, data, include }));
  } catch (e) { next(e); }
}

export async function deleteRequirement(req: Request, res: Response, next: NextFunction) { try { const u = await prisma.usuario.findUniqueOrThrow({ where: { id: req.userId! } }), row = await prisma.requerimiento.findUniqueOrThrow({ where: { id: String(req.params.id) } }); if (!u.isSuperAdmin && row.usuarioId !== u.id) throw new Error("Solo el solicitante puede eliminar este requerimiento"); await prisma.requerimiento.delete({ where: { id: row.id } }); res.json({ ok: true }); } catch (e) { next(e); } }

export async function flows(req: Request, res: Response, next: NextFunction) { try { const u = await prisma.usuario.findUniqueOrThrow({ where: { id: req.userId! } }); res.json(await prisma.flujoArea.findMany({ where: u.isSuperAdmin ? {} : { areaId: u.areaId }, include: { area: true, usuario: { select: { nombres: true, apellidos: true } } }, orderBy: { createdAt: "desc" } })); } catch (e) { next(e); } }
export async function createFlow(req: Request, res: Response, next: NextFunction) { try { const d = z.object({ titulo: z.string().min(3), descripcion: z.string().max(500).optional(), archivoNombre: z.string().max(255), archivoData: z.string().startsWith("data:application/pdf;base64,").max(4500000) }).parse(req.body), u = await prisma.usuario.findUniqueOrThrow({ where: { id: req.userId! } }); res.status(201).json(await prisma.flujoArea.create({ data: { ...d, areaId: u.areaId, usuarioId: u.id }, include: { area: true, usuario: { select: { nombres: true, apellidos: true } } } })); } catch (e) { next(e); } }
