import { NextFunction, Request, Response } from "express";
import { TipoMensaje } from "@prisma/client";
import { z } from "zod";
import { prisma } from "../config/db.js";

export async function conversations(
  req: Request,
  res: Response,
  next: NextFunction,
) {
  try {
    const id = req.userId!;
    const [coworkers, messages] = await Promise.all([
      prisma.usuario.findMany({
        where: { id: { not: id } },
        select: {
          id: true,
          nombres: true,
          apellidos: true,
          fotoPerfil: true,
          estadoMensaje: true,
          cargo: true,
          area: true,
        },
      }),
      prisma.mensaje.findMany({
        where: { OR: [{ remitenteId: id }, { destinatarioId: id }] },
        orderBy: { createdAt: "desc" },
      }),
    ]);
    res.json(
      coworkers
        .map((u) => ({
          id: u.id,
          nombres: u.nombres,
          apellidos: u.apellidos,
          fotoPerfil: u.fotoPerfil,
          estadoMensaje: u.estadoMensaje,
          cargo: u.cargo,
          area: u.area,
          lastMessage:
            messages.find(
              (m) =>
                (m.remitenteId === id && m.destinatarioId === u.id) ||
                (m.remitenteId === u.id && m.destinatarioId === id),
            ) ?? null,
          unread: messages.filter(
            (m) =>
              m.remitenteId === u.id && m.destinatarioId === id && !m.leidoAt,
          ).length,
        }))
        .sort(
          (a, b) =>
            new Date(b.lastMessage?.createdAt ?? 0).getTime() -
            new Date(a.lastMessage?.createdAt ?? 0).getTime(),
        ),
    );
  } catch (e) {
    next(e);
  }
}
export async function thread(req: Request, res: Response, next: NextFunction) {
  try {
    const other = String(req.params.userId),
      me = req.userId!;
    const rows = await prisma.mensaje.findMany({
      where: {
        OR: [
          { remitenteId: me, destinatarioId: other },
          { remitenteId: other, destinatarioId: me },
        ],
      },
      orderBy: { createdAt: "asc" },
    });
    await prisma.mensaje.updateMany({
      where: { remitenteId: other, destinatarioId: me, leidoAt: null },
      data: { leidoAt: new Date() },
    });
    res.json(rows);
  } catch (e) {
    next(e);
  }
}
export async function send(req: Request, res: Response, next: NextFunction) {
  try {
    const destinatarioId = z.string().uuid().parse(req.params.userId);
    const data = z
      .object({
        contenido: z.string().trim().max(2000).default(""),
        tipo: z.nativeEnum(TipoMensaje).default(TipoMensaje.Texto),
        archivoNombre: z.string().max(255).optional(),
        archivoMime: z.string().max(120).optional(),
        archivoData: z.string().max(3000000).optional(),
      })
      .refine((v) => v.contenido.length > 0 || Boolean(v.archivoData), {
        message: "El mensaje está vacío",
      })
      .parse(req.body);
    if (destinatarioId === req.userId)
      throw new Error("No puedes enviarte mensajes a ti mismo");
    await prisma.usuario.findUniqueOrThrow({ where: { id: destinatarioId } });
    res.status(201).json(
      await prisma.mensaje.create({
        data: { remitenteId: req.userId!, destinatarioId, ...data },
      }),
    );
  } catch (e) {
    next(e);
  }
}
