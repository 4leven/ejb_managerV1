import { NextFunction,Request,Response } from "express";
import { z } from "zod";
import { prisma } from "../config/db.js";
const createSchema=z.object({titulo:z.string().trim().min(2).max(220),estado:z.enum(["Pendiente","Iniciado","En_progreso"]).default("Pendiente")});
const updateSchema=z.object({estado:z.enum(["Pendiente","Iniciado","En_progreso","Completada"]),comentario:z.string().trim().max(600).optional()});
export async function addTask(req:Request,res:Response,next:NextFunction){try{await prisma.iniciativa.findUniqueOrThrow({where:{id:String(req.params.id)}});res.status(201).json(await prisma.tareaIniciativa.create({data:{iniciativaId:String(req.params.id),...createSchema.parse(req.body)}}))}catch(e){next(e)}}
export async function updateTask(req:Request,res:Response,next:NextFunction){try{const data=updateSchema.parse(req.body),completada=data.estado==="Completada";res.json(await prisma.tareaIniciativa.update({where:{id:String(req.params.taskId)},data:{...data,completada,completadaAt:completada?new Date():null}}))}catch(e){next(e)}}
