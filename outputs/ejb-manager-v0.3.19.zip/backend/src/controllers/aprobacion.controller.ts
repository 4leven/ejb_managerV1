import { AccionSolicitud, EstadoSolicitud, TipoEntidad } from "@prisma/client";
import { NextFunction, Request, Response } from "express";
import { z } from "zod";
import { prisma } from "../config/db.js";
const schema = z.object({
  tipoEntidad: z.nativeEnum(TipoEntidad),
  entidadId: z.string().uuid(),
  accion: z.nativeEnum(AccionSolicitud),
  payload: z.record(z.any()).optional(),
  motivo: z.string().min(3).max(500),
});
export async function requestChange(
  req: Request,
  res: Response,
  next: NextFunction,
) {
  try {
    const user = await prisma.usuario.findUniqueOrThrow({
      where: { id: req.userId! },
    });
    const data = schema.parse(req.body);
    if (user.isSuperAdmin) {
      await prisma.$transaction(async (tx) => {
        if (data.tipoEntidad === TipoEntidad.Iniciativa) {
          if (data.accion === AccionSolicitud.Eliminar)
            await tx.iniciativa.delete({ where: { id: data.entidadId } });
          else
            await tx.iniciativa.update({
              where: { id: data.entidadId },
              data: (data.payload ?? {}) as any,
            });
        } else {
          if (data.accion === AccionSolicitud.Eliminar)
            await tx.objetivoNegocio.delete({ where: { id: data.entidadId } });
          else
            await tx.objetivoNegocio.update({
              where: { id: data.entidadId },
              data: (data.payload ?? {}) as any,
            });
        }
      });
      return res
        .status(201)
        .json({ estado: EstadoSolicitud.Aprobada, appliedDirectly: true });
    }
    res.status(201).json(
      await prisma.solicitudCambio.create({
        data: {
          ...data,
          solicitanteId: user.id,
          areaId: user.areaId,
        },
      }),
    );
  } catch (e) {
    next(e);
  }
}
export async function pending(req: Request, res: Response, next: NextFunction) {
  try {
    const user = await prisma.usuario.findUniqueOrThrow({
      where: { id: req.userId! },
    });
    res.json(
      await prisma.solicitudCambio.findMany({
        where: {
          ...(user.isSuperAdmin ? {} : { areaId: user.areaId }),
          estado: EstadoSolicitud.Pendiente,
        },
        include: {
          solicitante: { select: { nombres: true, apellidos: true } },
          area: true,
        },
        orderBy: { createdAt: "desc" },
      }),
    );
  } catch (e) {
    next(e);
  }
}
export async function resolve(req: Request, res: Response, next: NextFunction) {
  try {
    const approved = z.boolean().parse(req.body.approved),
      user = await prisma.usuario.findUniqueOrThrow({
        where: { id: req.userId! },
      });
    if (user.cargo !== "Gerente" && !user.isSuperAdmin)
      throw new Error("Solo un Gerente puede aprobar cambios");
    const request = await prisma.solicitudCambio.findUniqueOrThrow({
      where: { id: String(req.params.id) },
    });
    if (
      (!user.isSuperAdmin && request.areaId !== user.areaId) ||
      request.estado !== EstadoSolicitud.Pendiente
    )
      throw new Error("Solicitud no disponible");
    await prisma.$transaction(async (tx) => {
      if (approved) {
        if (request.tipoEntidad === TipoEntidad.Iniciativa) {
          if (request.accion === AccionSolicitud.Eliminar)
            await tx.iniciativa.delete({ where: { id: request.entidadId } });
          else
            await tx.iniciativa.update({
              where: { id: request.entidadId },
              data: (request.payload ?? {}) as any,
            });
        } else {
          if (request.accion === AccionSolicitud.Eliminar)
            await tx.objetivoNegocio.delete({
              where: { id: request.entidadId },
            });
          else
            await tx.objetivoNegocio.update({
              where: { id: request.entidadId },
              data: (request.payload ?? {}) as any,
            });
        }
      }
      await tx.solicitudCambio.update({
        where: { id: request.id },
        data: {
          estado: approved
            ? EstadoSolicitud.Aprobada
            : EstadoSolicitud.Rechazada,
          aprobadorId: user.id,
          resolvedAt: new Date(),
        },
      });
    });
    res.json({ ok: true });
  } catch (e) {
    next(e);
  }
}
