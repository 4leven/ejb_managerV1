import { FormEvent, useEffect, useMemo, useRef, useState } from "react";
import EmojiPicker, { Categories, EmojiStyle, SkinTonePickerLocation, Theme } from "emoji-picker-react";
import {
  Check,
  ChevronDown,
  Download,
  FileText,
  Hash,
  Image,
  Settings,
  Shield,
  MessageCircle,
  Paperclip,
  Search,
  Send,
  Smile,
  Trash2,
  UserPlus,
  Users,
  Volume2,
  VolumeX,
  X,
} from "lucide-react";
import {
  fetchConversations,
  fetchMessages,
  saveMessageStatus,
  sendMessage,
  updateCollaboration,
} from "../api/iniciativas";
import { MessageSpaces, type RecordRow } from "./CollaborationModules";

type Conversation = {
  id: string;
  nombres: string;
  apellidos: string;
  fotoPerfil?: string | null;
  cargo: string;
  estadoMensaje: string;
  area: { nombre: string; colorHex: string };
  lastMessage?: { contenido: string; createdAt: string } | null;
  unread: number;
};
type Message = {
  id: string;
  remitenteId: string;
  destinatarioId: string;
  contenido: string;
  tipo: "Texto" | "Documento" | "Sticker";
  archivoNombre?: string;
  archivoMime?: string;
  archivoData?: string;
  createdAt: string;
};
type GifResult={id:string;title:string;url:string;preview_url:string;width:number;height:number};
const initials = (v: string) =>
  v
    .split(" ")
    .map((x) => x[0])
    .join("")
    .slice(0, 2);
const statusOptions = [
  { value: "Disponible", label: "Disponible" },
  { value: "Break", label: "Break" },
  { value: "Ausente", label: "Ausente" },
  { value: "Ocupado", label: "Ocupado" },
  { value: "No_molestar", label: "No molestar" },
];
const statusLabel = (value: string) => statusOptions.find(option => option.value === value)?.label ?? "Disponible";
export default function Messages({ currentUserId, currentStatus, onStatusChange, onIncomingMessage }: { currentUserId: string; currentStatus: string; onStatusChange: (status: string) => void; onIncomingMessage:(name:string,message:string,photo?:string|null)=>void }) {
  const [contacts, setContacts] = useState<Conversation[]>([]),
    [active, setActive] = useState<Conversation | null>(null),
    [messages, setMessages] = useState<Message[]>([]),
    [query, setQuery] = useState(""),
    [draft,setDraft]=useState(""),
    [activeSpace,setActiveSpace]=useState<RecordRow|null>(null),
    [spaceDraft,setSpaceDraft]=useState(""),
    [spaceSettings,setSpaceSettings]=useState(false),
    [statusOpen,setStatusOpen]=useState(false),
    [stickersOpen, setStickersOpen] = useState(false),
    [gifsOpen,setGifsOpen]=useState(false),
    [gifQuery,setGifQuery]=useState(""),
    [gifResults,setGifResults]=useState<GifResult[]>([]),
    [gifsLoading,setGifsLoading]=useState(false),
    [wallpaperOpen,setWallpaperOpen]=useState(false),
    [wallpaper,setWallpaper]=useState(()=>localStorage.getItem("ejb_chat_wallpaper")||"doodles");
  const messagesBox=useRef<HTMLDivElement|null>(null),messageInput=useRef<HTMLInputElement|null>(null),knownMessages=useRef<Set<string>>(new Set()),messageStreamReady=useRef(false);
  const loadContacts = () =>
    fetchConversations().then((rows: Conversation[]) => {
      setContacts(rows);
      setActive((activeContact) => activeContact ? rows.find(row => row.id === activeContact.id) ?? null : rows[0] ?? null);
    });
  useEffect(() => {
    loadContacts();
    const timer = setInterval(loadContacts, 5000);
    return () => clearInterval(timer);
  }, []);
  useEffect(() => {
    if (!active) return;
    knownMessages.current=new Set();messageStreamReady.current=false;
    const load = () => fetchMessages(active.id).then((rows:Message[])=>{if(messageStreamReady.current){const incoming=rows.find(row=>row.remitenteId!==currentUserId&&!knownMessages.current.has(row.id));if(incoming)onIncomingMessage(`${active.nombres} ${active.apellidos}`,incoming.contenido,active.fotoPerfil)}knownMessages.current=new Set(rows.map(row=>row.id));messageStreamReady.current=true;setMessages(rows)});
    load();
    const timer = setInterval(load, 4000);
    return () => clearInterval(timer);
  }, [active?.id]);
  useEffect(()=>{const box=messagesBox.current;if(box)box.scrollTo({top:box.scrollHeight,behavior:"smooth"})},[messages]);
  useEffect(()=>{if(!gifsOpen)return;const controller=new AbortController(),timer=setTimeout(async()=>{setGifsLoading(true);try{const endpoint=gifQuery.trim()?`https://gifsnap.com/api/v1/gifs/search?q=${encodeURIComponent(gifQuery.trim())}&page=1&limit=24`:`https://gifsnap.com/api/v1/gifs/trending?page=1&limit=24`;const response=await fetch(endpoint,{signal:controller.signal});if(!response.ok)throw new Error();const body=await response.json();setGifResults(body.data??[])}catch(error){if((error as Error).name!=="AbortError")setGifResults([])}finally{setGifsLoading(false)}},gifQuery?350:0);return()=>{clearTimeout(timer);controller.abort()}},[gifsOpen,gifQuery]);
  const filtered = useMemo(
    () =>
      contacts.filter((c) =>
        `${c.nombres} ${c.apellidos}`
          .toLowerCase()
          .includes(query.toLowerCase()),
      ),
    [contacts, query],
  );
  const submit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!active) return;
    if (!draft.trim()) return;
    const row = await sendMessage(active.id, draft);
    setMessages((v) => [...v, row]);
    setDraft("");
  };
  const sendSticker = (sticker: string) => {
    setDraft((value)=>`${value}${sticker}`);
    setStickersOpen(false);
    requestAnimationFrame(()=>messageInput.current?.focus());
  };
  const sendSpaceMessage=async(e:FormEvent<HTMLFormElement>)=>{e.preventDefault();if(!activeSpace||!spaceDraft.trim())return;const mensajes=[...(activeSpace.datos.mensajes??[]),{id:crypto.randomUUID(),usuarioId:currentUserId,autor:"Yo",texto:spaceDraft.trim(),fecha:new Date().toISOString()}],updated=await updateCollaboration(activeSpace.datos.tipo??(activeSpace.datos.esCanal?"canal":"grupo"),activeSpace.id,{...activeSpace.datos,mensajes});setActiveSpace(updated);setSpaceDraft("")};
  const sendSpaceGif=async(gif:GifResult)=>{if(!activeSpace)return;const mensajes=[...(activeSpace.datos.mensajes??[]),{id:crypto.randomUUID(),usuarioId:currentUserId,autor:"Yo",texto:gif.title||"GIF",tipo:"Gif",archivoData:gif.url,fecha:new Date().toISOString()}],updated=await updateCollaboration(activeSpace.datos.tipo??(activeSpace.datos.esCanal?"canal":"grupo"),activeSpace.id,{...activeSpace.datos,mensajes});setActiveSpace(updated);setGifsOpen(false)};
  const saveSpace=async(datos:any)=>{if(!activeSpace)return;const updated=await updateCollaboration(activeSpace.datos.tipo??(activeSpace.datos.esCanal?"canal":"grupo"),activeSpace.id,datos);setActiveSpace(updated)};
  const chooseWallpaper=(value:string)=>{setWallpaper(value);localStorage.setItem("ejb_chat_wallpaper",value);setWallpaperOpen(false)};
  const saveSpacePhoto=(input:HTMLInputElement)=>{const file=input.files?.[0];if(!file||!activeSpace)return;if(!file.type.startsWith("image/")||file.size>2000000)return alert("Selecciona una imagen menor a 2 MB");const reader=new FileReader();reader.onload=()=>saveSpace({...activeSpace.datos,foto:String(reader.result)});reader.readAsDataURL(file)};
  const members:string[]=activeSpace?Array.from(new Set<string>((activeSpace.datos.miembros??[activeSpace.creador.id]) as string[])):[];
  const moderators:string[]=activeSpace?Array.from(new Set<string>((activeSpace.datos.moderadores??[]) as string[])):[];
  const muted=activeSpace?(activeSpace.datos.silenciados??[]).includes(currentUserId):false;
  const canManage=Boolean(activeSpace&&(activeSpace.creador.id===currentUserId||moderators.includes(currentUserId)));
  const sendFile = (input: HTMLInputElement) => {
    const file = input.files?.[0];
    if (!file || !active) return;
    if (file.size > 2000000)
      return alert("El documento debe pesar menos de 2 MB");
    const reader = new FileReader();
    reader.onload = async () => {
      const row = await sendMessage(active.id, {
        contenido: file.name,
        tipo: "Documento",
        archivoNombre: file.name,
        archivoMime: file.type || "application/octet-stream",
        archivoData: String(reader.result),
      });
      setMessages((v) => [...v, row]);
      input.value = "";
    };
    reader.readAsDataURL(file);
  };
  const sendGif=async(gif:GifResult)=>{if(!active)return;const row=await sendMessage(active.id,{contenido:gif.title||"GIF",tipo:"Documento",archivoNombre:gif.title||"GIF",archivoMime:"image/gif",archivoData:gif.url});setMessages(v=>[...v,row]);setGifsOpen(false)};
  const gifPicker=(onChoose:(gif:GifResult)=>void)=><div className="gif-picker"><header><div><b>GIFs</b><small>Busca y selecciona una animaciÃ³n</small></div><button type="button" onClick={()=>setGifsOpen(false)}><X/></button></header><div className="gif-search"><Search/><input autoFocus value={gifQuery} onChange={e=>setGifQuery(e.target.value)} placeholder="Buscar GIFs..."/></div><div className="gif-grid">{gifsLoading?<div className="gif-loading"><i/><span>Buscando GIFs...</span></div>:gifResults.map(gif=><button type="button" key={gif.id} onClick={()=>onChoose(gif)} title={gif.title}><img src={gif.preview_url||gif.url} alt={gif.title||"GIF"} loading="lazy"/></button>)}{!gifsLoading&&!gifResults.length&&<div className="gif-empty"><Image/><b>No encontramos resultados</b><span>Prueba con otra bÃºsqueda.</span></div>}</div><footer>Tendencias y bÃºsqueda en lÃ­nea</footer></div>;
  return (<div className={`messages-hub wallpaper-${wallpaper}`}><aside className="message-space-column"><div className="telegram-space-title"><span><MessageCircle/></span><div><b>EJB Chat</b><small>Mensajería del equipo</small></div><button onClick={()=>setWallpaperOpen(value=>!value)} title="Personalizar fondo"><Image/></button></div><MessageSpaces currentUserId={currentUserId} activeId={activeSpace?.id} onSelect={row=>{setActiveSpace(row);setActive(null);setStatusOpen(false)}}/>{wallpaperOpen&&<div className="wallpaper-popover"><div><b>Fondo del chat</b><button type="button" onClick={()=>setWallpaperOpen(false)}><X/></button></div><p>Elige un ambiente para tus conversaciones.</p><div className="wallpaper-options">{[{id:"doodles",name:"Doodles"},{id:"aurora",name:"Aurora"},{id:"ocean",name:"Océano"},{id:"paper",name:"Claro"}].map(option=><button type="button" key={option.id} className={`wallpaper-swatch wallpaper-${option.id} ${wallpaper===option.id?"active":""}`} onClick={()=>chooseWallpaper(option.id)}><i/>{option.name}{wallpaper===option.id&&<Check/>}</button>)}</div></div>}</aside>
    <div className="messenger">
      <aside className="conversation-list">
        <div className="my-message-status">
          <span>Mi estado</span>
          <button type="button" className="status-trigger" data-status={currentStatus} aria-expanded={statusOpen} onClick={()=>setStatusOpen(open=>!open)}>
            <i /><b>{statusLabel(currentStatus)}</b><ChevronDown />
          </button>
          {statusOpen&&<div className="status-menu" role="listbox" aria-label="Seleccionar mi estado">
            {statusOptions.map(option=><button type="button" role="option" aria-selected={currentStatus===option.value} data-status={option.value} key={option.value} onClick={async()=>{
              await saveMessageStatus(option.value);
              onStatusChange(option.value);
              setStatusOpen(false);
            }}><i/><span><b>{option.label}</b><small>{option.value==="Disponible"?"Listo para responder":option.value==="Break"?"En una pausa breve":option.value==="Ausente"?"Fuera por el momento":option.value==="Ocupado"?"Atendiendo otra tarea":"Evitar interrupciones"}</small></span>{currentStatus===option.value&&<Check/>}</button>)}
          </div>}
        </div>
        <div className="message-search">
          <Search />
          <input
            placeholder="Buscar compañero"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
        </div>
        {filtered.map((c) => (
          <button
            key={c.id}
            className={active?.id === c.id ? "active" : ""}
            onClick={() => {setActive(c);setActiveSpace(null);setStatusOpen(false)}}
          >
            {c.fotoPerfil ? (
              <img src={c.fotoPerfil} />
            ) : (
              <div style={{ background: c.area.colorHex }}>
                {initials(`${c.nombres} ${c.apellidos}`)}
              </div>
            )}
            <p>
              <b>
                {c.nombres} {c.apellidos}
              </b>
              <span className="contact-status" data-status={c.estadoMensaje}><i />{statusLabel(c.estadoMensaje)}</span>
              <small>
                {c.lastMessage?.contenido ?? `${c.cargo} · ${c.area.nombre}`}
              </small>
            </p>
            {c.unread > 0 && <span>{c.unread}</span>}
          </button>
        ))}
        {!filtered.length && (
          <div className="no-contacts">No hay compañeros registrados.</div>
        )}
      </aside>
      <section className="chat-panel">
        {activeSpace ? <><header className="space-chat-header"><div>{activeSpace.datos.esCanal?<Hash/>:<Users/>}</div><p><b>{activeSpace.datos.nombre}</b><small>{activeSpace.datos.descripcion||"Conversación del equipo"}</small></p>{muted&&<span className="muted-space"><VolumeX/>SILENCIADO</span>}<button className="space-settings-button" onClick={()=>setSpaceSettings(true)} title="Administrar espacio"><Settings/></button><span>{activeSpace.datos.esCanal?"CANAL":"GRUPO"}</span></header><div className="messages space-messages-inline" ref={messagesBox}>{(activeSpace.datos.mensajes??[]).map((m:any)=><article className={m.usuarioId===currentUserId?"mine":""} key={m.id}><b>{m.autor}</b>{m.tipo==="Gif"?<img className="gif-message" src={m.archivoData} alt="GIF compartido"/>:<p>{m.texto}</p>}<small>{new Date(m.fecha).toLocaleString("es-PE")}</small></article>)}{!activeSpace.datos.mensajes?.length&&<div className="start-chat"><MessageCircle/><b>Inicia la conversación del equipo</b><span>El historial quedará guardado en este espacio.</span></div>}</div><form className="space-composer-inline" onSubmit={sendSpaceMessage}><button type="button" className="chat-tool gif-tool" title="Buscar GIF" onClick={()=>{setStickersOpen(false);setGifsOpen(value=>!value)}}><b>GIF</b></button>{gifsOpen&&gifPicker(sendSpaceGif)}<input value={spaceDraft} onChange={e=>setSpaceDraft(e.target.value)} placeholder="Escribe al grupo o canal..."/><button><Send/></button></form></> : active ? (
          <>
            <header>
              {active.fotoPerfil ? <img className="chat-header-photo" src={active.fotoPerfil} alt={`Foto de ${active.nombres} ${active.apellidos}`} /> : <div style={{ background: active.area.colorHex }}>{initials(`${active.nombres} ${active.apellidos}`)}</div>}
              <p>
                <b>
                  {active.nombres} {active.apellidos}
                </b>
                <span className="contact-status" data-status={active.estadoMensaje}><i />{statusLabel(active.estadoMensaje)}</span>
                <small>
                  {active.cargo} · {active.area.nombre}
                </small>
              </p>
              <button className="wallpaper-button" onClick={()=>setWallpaperOpen(value=>!value)} title="Cambiar fondo del chat"><Image/></button>
            </header>
            <div className={`messages telegram-wallpaper wallpaper-${wallpaper}`} ref={messagesBox}>
              {messages.map((m) => (
                <article
                  key={m.id}
                  className={m.remitenteId === currentUserId ? "mine" : ""}
                >
                  {m.tipo === "Sticker" ? (
                    <div className="sticker-message">{m.contenido}</div>
                  ) : m.tipo === "Documento" && m.archivoMime === "image/gif" ? (
                    <img className="gif-message" src={m.archivoData} alt={m.archivoNombre || "GIF compartido"} />
                  ) : m.tipo === "Documento" ? (
                    <a
                      className="document-message"
                      href={m.archivoData}
                      download={m.archivoNombre}
                    >
                      <FileText />
                      <span>
                        <b>{m.archivoNombre}</b>
                        <small>Documento adjunto</small>
                      </span>
                      <Download />
                    </a>
                  ) : (
                    <p>{m.contenido}</p>
                  )}
                  <small>
                    {new Date(m.createdAt).toLocaleTimeString([], {
                      hour: "2-digit",
                      minute: "2-digit",
                    })}
                  </small>
                </article>
              ))}
              {!messages.length && (
                <div className="start-chat">
                  <MessageCircle />
                  <b>Inicia la conversación</b>
                  <span>Los mensajes quedan guardados de forma privada.</span>
                </div>
              )}
            </div>
            <form onSubmit={submit}>
              <label className="chat-tool" title="Adjuntar documento">
                <Paperclip />
                <input
                  type="file"
                  onChange={(e) => sendFile(e.currentTarget)}
                />
              </label>
              <button type="button" className="chat-tool gif-tool" title="Buscar GIF" onClick={()=>{setStickersOpen(false);setGifsOpen(value=>!value)}}>
                <b>GIF</b>
              </button>
              {gifsOpen&&gifPicker(sendGif)}
              <button
                type="button"
                className="chat-tool"
                onClick={() => setStickersOpen((v) => !v)}
                title="Stickers"
              >
                <Smile />
              </button>
              {stickersOpen && (
                <div className="sticker-picker">
                  <EmojiPicker
                    theme={document.documentElement.classList.contains("dark")?Theme.DARK:Theme.LIGHT}
                    emojiStyle={EmojiStyle.NATIVE}
                    searchPlaceHolder="Buscar emoji..."
                    previewConfig={{showPreview:false}}
                    skinTonePickerLocation={SkinTonePickerLocation.PREVIEW}
                    categories={[
                      {category:Categories.SUGGESTED,name:"Recientes"},{category:Categories.SMILEYS_PEOPLE,name:"Caras y personas"},{category:Categories.ANIMALS_NATURE,name:"Animales y naturaleza"},{category:Categories.FOOD_DRINK,name:"Comida y bebida"},{category:Categories.TRAVEL_PLACES,name:"Viajes y lugares"},{category:Categories.ACTIVITIES,name:"Actividades"},{category:Categories.OBJECTS,name:"Objetos"},{category:Categories.SYMBOLS,name:"Símbolos"},{category:Categories.FLAGS,name:"Banderas"}
                    ]}
                    categoryIcons={{
                      suggested:<span>🕘</span>,smileys_people:<span>😀</span>,animals_nature:<span>🐻</span>,food_drink:<span>🍔</span>,travel_places:<span>✈️</span>,activities:<span>⚽</span>,objects:<span>💡</span>,symbols:<span>❤️</span>,flags:<span>🏳️</span>
                    }}
                    lazyLoadEmojis width="100%" height={420}
                    onEmojiClick={(emoji)=>sendSticker(emoji.emoji)}
                  />
                  {false&&[
                    "👍",
                    "🎉",
                    "🚀",
                    "✅",
                    "👏",
                    "💡",
                    "🔥",
                    "💪",
                    "⭐",
                    "😊",
                    "🤝",
                    "📌",
                  ].map((s) => (
                    <button
                      type="button"
                      key={s}
                      onClick={() => sendSticker(s)}
                    >
                      {s}
                    </button>
                  ))}
                </div>
              )}
              <input
                ref={messageInput}
                name="message"
                autoComplete="off"
                placeholder="Escribe un mensaje..."
                value={draft}
                onChange={(e)=>setDraft(e.target.value)}
              />
              <button>
                <Send />
              </button>
            </form>
          </>
        ) : (
          <div className="start-chat">
            <MessageCircle />
            <b>Mensajes EJB</b>
            <span>Selecciona un compañero para conversar.</span>
          </div>
        )}
      </section>
      {activeSpace&&spaceSettings&&<div className="overlay group-settings-overlay"><section className="group-settings-modal"><button className="close" onClick={()=>setSpaceSettings(false)}><X/></button><div className="group-settings-title"><span>{activeSpace.datos.esCanal?<Hash/>:<Users/>}</span><div><small>GESTIÓN DEL ESPACIO</small><h2>{activeSpace.datos.nombre}</h2><p>{members.length} integrante(s) · {moderators.length} moderador(es)</p></div></div><button className={`mute-space ${muted?"active":""}`} onClick={()=>saveSpace({...activeSpace.datos,silenciados:muted?(activeSpace.datos.silenciados??[]).filter((id:string)=>id!==currentUserId):[...(activeSpace.datos.silenciados??[]),currentUserId]})}>{muted?<Volume2/>:<VolumeX/>}<span><b>{muted?"Activar notificaciones":"Silenciar mensajes"}</b><small>{muted?"Volverás a recibir avisos de este espacio.":"Seguirás viendo el historial sin recibir avisos."}</small></span></button>{canManage&&<div className="add-space-member"><UserPlus/><select defaultValue="" onChange={async e=>{if(!e.target.value)return;await saveSpace({...activeSpace.datos,miembros:[...members,e.target.value]});e.target.value=""}}><option value="">Agregar una persona…</option>{contacts.filter(contact=>!members.includes(contact.id)).map(contact=><option key={contact.id} value={contact.id}>{contact.nombres} {contact.apellidos} · {contact.area.nombre}</option>)}</select></div>}<div className="space-member-list">{members.map((id:string)=>{const person=contacts.find(contact=>contact.id===id),isOwner=id===activeSpace.creador.id,isModerator=moderators.includes(id);return <article key={id}><span style={{background:person?.area.colorHex??"#2f6fed"}}>{person?initials(`${person.nombres} ${person.apellidos}`):id===currentUserId?"YO":"EJB"}</span><div><b>{person?`${person.nombres} ${person.apellidos}`:id===currentUserId?"Tú":`${activeSpace.creador.nombres} ${activeSpace.creador.apellidos}`}</b><small>{isOwner?"Creador":isModerator?"Moderador":"Integrante"}</small></div>{canManage&&!isOwner&&<><button className={isModerator?"moderator active":"moderator"} onClick={()=>saveSpace({...activeSpace.datos,moderadores:isModerator?moderators.filter((memberId:string)=>memberId!==id):[...moderators,id]})}><Shield/>{isModerator?"Quitar moderador":"Hacer moderador"}</button><button className="remove-member" onClick={()=>saveSpace({...activeSpace.datos,miembros:members.filter((memberId:string)=>memberId!==id),moderadores:moderators.filter((memberId:string)=>memberId!==id)})}><Trash2/>Retirar</button></>}</article>})}</div>{!canManage&&<p className="settings-note"><Shield/>Solo el creador y los moderadores pueden administrar integrantes.</p>}</section></div>}
    </div></div>);
}
