import { StrictMode } from 'react'; import { createRoot } from 'react-dom/client'; import App from './App'; import {ErrorBoundary,ConnectionStatus} from './components/AppSafety'; import {uiAlert} from './utils/dialog'; import './styles.css'; import './enhancements.css'; import './refinements.css';
window.alert=(message?:any)=>{void uiAlert('EJB MANAGER',String(message??''))};
createRoot(document.getElementById('root')!).render(<StrictMode><ErrorBoundary><ConnectionStatus/><App/></ErrorBoundary></StrictMode>);
