import { FormEvent, useEffect, useState } from "react";
import {
  CheckCircle2,
  ClipboardList,
  FileText,
  Pencil,
  Plus,
  Trash2,
  Upload,
  X,
} from "lucide-react";
import {
  createFlow,
  addFlowVersion,
  deleteFlow,
  createRequirement,
  deleteRequirement,
  fetchFlows,
  fetchRequirements,
  updateRequirement,
} from "../api/iniciativas";
import { uiAlert, uiConfirm, uiPrompt } from "../utils/dialog";

const statuses = [
  "Pendiente",
  "En curso",
  "Aprobado",
  "Entregado",
  "Desaprobado",
];
export function Requirements({ user }: { user: any }) {
  const [rows, setRows] = useState<any[]>([]),
    [modal, setModal] = useState(false);
  const load = () => fetchRequirements().then(setRows);
  useEffect(() => {
    load();
  }, []);
  const submit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    await createRequirement({
      titulo: String(f.get("titulo")),
      descripcion: String(f.get("descripcion")),
      cantidad: Number(f.get("cantidad")),
      prioridad: String(f.get("prioridad")),
      estado: "Pendiente",
      fechaNecesaria: String(f.get("fechaNecesaria")),
    });
    setModal(false);
    load();
  };
  const edit = async (r: any) => {
    const titulo = await uiPrompt("Editar requerimiento", r.titulo, {
      message: "Nombre del producto o recurso solicitado.",
    });
    if (!titulo) return;
    const descripcion = await uiPrompt(
      "Detalle del requerimiento",
      r.descripcion ?? "",
      { multiline: true },
    );
    if (descripcion === null) return;
    const cantidad = Number(await uiPrompt("Cantidad", String(r.cantidad)));
    if (!cantidad) return;
    await updateRequirement(r.id, { titulo, descripcion, cantidad });
    load();
  };
  const remove = async (r: any) => {
    if (
      await uiConfirm(
        "Eliminar requerimiento",
        `¿Deseas eliminar “${r.titulo}”?`,
      )
    ) {
      await deleteRequirement(r.id);
      load();
    }
  };
  const setStatus = async (r: any, estado: string) => {
    await updateRequirement(r.id, { estado });
    load();
  };
  const isAdministration = user.area?.nombre === "Administración",
    canOwn = (r: any) => user.isSuperAdmin || r.usuario.id === user.id;
  return (
    <>
      <div className="module-actions">
        <div className="request-intro">
          <ClipboardList />
          <div>
            <b>Solicitudes internas</b>
            <small>Café, útiles, materiales, equipos y otros recursos.</small>
          </div>
        </div>
        <button className="primary" onClick={() => setModal(true)}>
          <Plus />
          Nuevo requerimiento
        </button>
      </div>
      <div className="request-grid">
        {rows.map((r) => (
          <article key={r.id}>
            <div className={`request-priority ${r.prioridad.toLowerCase()}`}>
              {r.prioridad}
            </div>
            <h3>{r.titulo}</h3>
            <p>{r.descripcion || "Sin descripción"}</p>
            <div>
              <span>{r.cantidad} unidad(es)</span>
              <span>{r.area.nombre}</span>
            </div>
            <small>
              Solicitado por {r.usuario.nombres} {r.usuario.apellidos} ·{" "}
              {new Date(r.createdAt).toLocaleDateString()}
            </small>
            <div className="requirement-footer">
              <span className="requirement-status">{r.estado}</span>
              {isAdministration || user.isSuperAdmin ? (
                <select
                  aria-label={`Estado de ${r.titulo}`}
                  value={statuses.includes(r.estado) ? r.estado : "Pendiente"}
                  onChange={(e) => setStatus(r, e.target.value)}
                >
                  {statuses.map((s) => (
                    <option key={s}>{s}</option>
                  ))}
                </select>
              ) : null}
              <div className="requirement-actions">
                {canOwn(r) && (
                  <button onClick={() => edit(r)}>
                    <Pencil />
                    Editar
                  </button>
                )}
                {canOwn(r) && (
                  <button className="danger" onClick={() => remove(r)}>
                    <Trash2 />
                    Eliminar
                  </button>
                )}
              </div>
            </div>
          </article>
        ))}
      </div>
      {modal && (
        <div className="overlay">
          <form className="event-modal" onSubmit={submit}>
            <button
              type="button"
              className="close"
              aria-label="Cerrar"
              onClick={() => setModal(false)}
            >
              <X />
            </button>
            <ClipboardList />
            <h2>Nuevo requerimiento</h2>
            <div className="requester-summary">
              <label>
                Solicitante
                <input value={`${user.nombres} ${user.apellidos}`} readOnly />
              </label>
              <label>
                Área
                <input value={user.area?.nombre ?? "Sin área"} readOnly />
              </label>
            </div>
            <label>
              ¿Qué necesitas?
              <input name="titulo" required placeholder="Ej. Hojas bond A4" />
            </label>
            <label>
              Detalle
              <textarea name="descripcion" />
            </label>
            <div className="event-grid">
              <label>
                Cantidad
                <input name="cantidad" type="number" min="1" defaultValue="1" />
              </label>
              <label>
                Fecha necesaria
                <input name="fechaNecesaria" type="date" />
              </label>
              <label>
                Prioridad
                <select name="prioridad">
                  <option>Baja</option>
                  <option>Normal</option>
                  <option>Alta</option>
                  <option>Urgente</option>
                </select>
              </label>
            </div>
            <button className="primary">Enviar solicitud</button>
          </form>
        </div>
      )}
    </>
  );
}

export function AreaFlows() {
  const [rows, setRows] = useState<any[]>([]),
    [preview, setPreview] = useState<any>(null),
    [message, setMessage] = useState("");
  const load = () => fetchFlows().then(setRows);
  useEffect(() => {
    load();
  }, []);
  const submit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = e.currentTarget,
      f = new FormData(form),
      file = f.get("pdf") as File;
    if (!file || file.type !== "application/pdf" || file.size > 3000000)
      return alert("Selecciona un PDF menor a 3 MB");
    const data = await new Promise<string>((ok) => {
      const r = new FileReader();
      r.onload = () => ok(String(r.result));
      r.readAsDataURL(file);
    });
    await createFlow({
      titulo: String(f.get("titulo")),
      descripcion: String(f.get("descripcion")),
      archivoNombre: file.name,
      archivoData: data,
    });
    form.reset();
    setMessage("PDF publicado correctamente. Ya puedes previsualizarlo.");
    await load();
  };
  const addVersion=async(input:HTMLInputElement)=>{const file=input.files?.[0];if(!file||!preview)return;if(file.type!=="application/pdf"||file.size>3000000)return uiAlert("Archivo inválido","Selecciona un PDF menor a 3 MB");const data=await new Promise<string>(resolve=>{const reader=new FileReader();reader.onload=()=>resolve(String(reader.result));reader.readAsDataURL(file)});await addFlowVersion(preview.id,{archivoNombre:file.name,archivoData:data});setMessage("Nueva versión publicada correctamente.");setPreview(null);await load()};
  return (
    <div className="flows-layout">
      <form className="flow-upload" onSubmit={submit}>
        <Upload />
        <h3>Subir flujo de trabajo</h3>
        <p>Comparte procedimientos y manuales PDF con tu área.</p>
        {message && (
          <div className="inline-success">
            <CheckCircle2 />
            {message}
          </div>
        )}
        <label>
          Título
          <input name="titulo" required />
        </label>
        <label>
          Descripción
          <textarea name="descripcion" />
        </label>
        <label className="pdf-drop">
          <FileText />
          Seleccionar PDF
          <input name="pdf" type="file" accept="application/pdf" required />
        </label>
        <button className="primary">Publicar flujo</button>
      </form>
      <div className="flow-list">
        {rows.map((r) => (
          <article key={r.id} onClick={() => setPreview(r)}>
            <FileText />
            <div>
              <b>{r.titulo}</b>
              <p>{r.descripcion || r.archivoNombre}</p>
              <small>
                {r.area.nombre} · {r.usuario.nombres} {r.usuario.apellidos}
              </small>
              <small>{r.versiones?.length||1} versión(es)</small>
            </div>
            <span>Previsualizar</span>
          </article>
        ))}
      </div>
      {preview && (
        <div className="overlay">
          <section className="pdf-modal">
            <button
              className="close"
              aria-label="Cerrar"
              onClick={() => setPreview(null)}
            >
              <X />
            </button>
            <h2>{preview.titulo}</h2>
            <div className="document-version-tools"><a href={preview.archivoData} download={preview.archivoNombre}>Descargar versión actual</a><label><Upload/>Subir nueva versión<input type="file" accept="application/pdf" onChange={e=>addVersion(e.currentTarget)}/></label><button className="danger" onClick={async()=>{if(await uiConfirm("Enviar a la papelera",`¿Deseas retirar ${preview.titulo}?`)){await deleteFlow(preview.id);setPreview(null);load()}}}><Trash2/>Papelera</button></div>
            <div className="document-version-history"><b>Historial de versiones</b>{preview.versiones?.map((version:any)=><span key={version.id}>v{version.version} · {version.archivoNombre} · {new Date(version.createdAt).toLocaleString("es-PE")}</span>)}</div>
            <iframe src={preview.archivoData} title={preview.titulo} />
          </section>
        </div>
      )}
    </div>
  );
}
