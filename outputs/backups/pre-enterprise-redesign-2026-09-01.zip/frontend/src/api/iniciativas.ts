export const API_URL=import.meta.env.VITE_API_URL??'/api';
const authHeaders=()=>({Authorization:`Bearer ${localStorage.getItem('ejb_token')??''}`});
export async function downloadMonthlyReport(format:'pdf'|'xls',filters:{month?:string;area?:string;client?:string;compare?:boolean}={}){
  const params=new URLSearchParams({format});if(filters.month)params.set('month',filters.month);if(filters.area)params.set('area',filters.area);if(filters.client)params.set('client',filters.client);if(filters.compare)params.set('compare','1');
  const response=await fetch(`${API_URL}/dashboard/reporte-mensual?${params}`,{headers:authHeaders()});
  if(!response.ok){const error=await response.json().catch(()=>({}));throw new Error(error.message??'No se pudo descargar el reporte')}
  const blob=await response.blob(),disposition=response.headers.get('Content-Disposition')??'';
  const filename=disposition.match(/filename="?([^";]+)"?/i)?.[1]??`reporte-mensual.${format}`;
  const url=URL.createObjectURL(blob),anchor=document.createElement('a');anchor.href=url;anchor.download=filename;document.body.appendChild(anchor);anchor.click();anchor.remove();URL.revokeObjectURL(url);
}
export async function fetchIniciativas(){const r=await fetch(`${API_URL}/iniciativas`,{headers:authHeaders()});if(!r.ok)throw new Error('No se pudo conectar');return r.json()}
export async function fetchCatalogo(){const r=await fetch(`${API_URL}/usuarios/catalogo`);if(!r.ok)throw new Error('No se pudo cargar el catálogo');return r.json()}
export async function createIniciativa(data:{titulo:string;descripcion:string;cliente?:string;areaId:string;impacto:number;esfuerzo:string;fechaInicio?:string;fechaFin?:string;tareas?:string[]}){const r=await fetch(`${API_URL}/iniciativas`,{method:'POST',headers:{'Content-Type':'application/json',...authHeaders()},body:JSON.stringify(data)});if(!r.ok){const error=await r.json().catch(()=>({}));throw new Error(error.message??'No se pudo registrar')}return r.json()}
export async function register(data:Record<string,string>){const r=await fetch(`${API_URL}/auth/registro`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});const body=await r.json();if(!r.ok)throw new Error(body.message??'No se pudo crear la cuenta');return body}
export async function login(email:string,password:string){const r=await fetch(`${API_URL}/auth/login`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email,password})});const body=await r.json();if(!r.ok)throw new Error(body.message??'No se pudo iniciar sesión');return body}
export async function me(){const r=await fetch(`${API_URL}/auth/me`,{headers:authHeaders()});if(!r.ok)throw new Error('Sesión inválida');return r.json()}
async function jsonRequest(path:string,options:RequestInit={}){const r=await fetch(`${API_URL}${path}`,{...options,headers:{'Content-Type':'application/json',...authHeaders(),...(options.headers??{})}});const body=await r.json();if(!r.ok)throw new Error(body.message??'No se pudo completar la operación');return body}
export const fetchObjetivos=()=>jsonRequest('/objetivos');
export const createObjetivo=(data:{nombre:string;descripcion:string})=>jsonRequest('/objetivos',{method:'POST',body:JSON.stringify(data)});
export const addObjectiveProgress=(id:string,data:{porcentaje:number;comentario:string})=>jsonRequest(`/objetivos/${id}/progresos`,{method:'POST',body:JSON.stringify(data)});
export const fetchEquipo=()=>jsonRequest('/usuarios/equipo');
export const saveTeamCargo=(id:string,cargo:string)=>jsonRequest(`/usuarios/equipo/${id}/cargo`,{method:'PATCH',body:JSON.stringify({cargo})});
export const deleteTeamMember=(id:string)=>jsonRequest(`/usuarios/equipo/${id}`,{method:'DELETE'});
export const savePortalColor=(portalColor:string)=>jsonRequest('/usuarios/me/color',{method:'PATCH',body:JSON.stringify({portalColor})});
export const fetchProgresos=(id:string)=>jsonRequest(`/iniciativas/${id}/progresos`);
export const addProgreso=(id:string,data:{porcentaje:number;comentario:string})=>jsonRequest(`/iniciativas/${id}/progresos`,{method:'POST',body:JSON.stringify(data)});
export const addInitiativeTask=(id:string,data:{titulo:string;estado?:string;comentario?:string;fechaInicio?:string;fechaFin?:string;prioridad?:string;responsableId?:string|null;recordatorioAt?:string|null;adjuntos?:{nombre:string;mime:string;data:string}[]})=>jsonRequest(`/iniciativas/${id}/tareas`,{method:'POST',body:JSON.stringify(data)});
export const updateInitiativeTask=(id:string,taskId:string,data:{estado:string;comentario?:string;fechaInicio?:string;fechaFin?:string;prioridad?:string;responsableId?:string|null;recordatorioAt?:string|null;adjuntos?:{nombre:string;mime:string;data:string}[]})=>jsonRequest(`/iniciativas/${id}/tareas/${taskId}`,{method:'PATCH',body:JSON.stringify(data)});
export const saveInitiativeAppearance=(id:string,data:{icono:string;colorIcono:string})=>jsonRequest(`/iniciativas/${id}/apariencia`,{method:'PATCH',body:JSON.stringify(data)});
export const updateInitiative=(id:string,data:{titulo:string;descripcion:string;cliente?:string;areaId:string})=>jsonRequest(`/iniciativas/${id}`,{method:'PATCH',body:JSON.stringify(data)});
export const deleteInitiative=(id:string)=>jsonRequest(`/iniciativas/${id}`,{method:'DELETE'});
export const fetchConversations=()=>jsonRequest('/mensajes/conversaciones');
export const saveMessageStatus=(estadoMensaje:string)=>jsonRequest('/usuarios/me/estado-mensaje',{method:'PATCH',body:JSON.stringify({estadoMensaje})});
export const fetchMessages=(userId:string)=>jsonRequest(`/mensajes/${userId}`);
export const sendMessage=(userId:string,data:string|Record<string,unknown>)=>jsonRequest(`/mensajes/${userId}`,{method:'POST',body:JSON.stringify(typeof data==='string'?{contenido:data}:data)});
export const fetchAlerts=()=>jsonRequest('/alertas');
export async function subscribeAlerts(onAlerts:(rows:any[])=>void,signal:AbortSignal){
  const response=await fetch(`${API_URL}/alertas/stream`,{headers:{Accept:'text/event-stream',...authHeaders()},signal});
  if(!response.ok||!response.body)throw new Error('No se pudo abrir el canal de alertas');
  const reader=response.body.getReader(),decoder=new TextDecoder();let buffer='';
  while(!signal.aborted){
    const {done,value}=await reader.read();if(done)break;
    buffer+=decoder.decode(value,{stream:true});
    const blocks=buffer.split('\n\n');buffer=blocks.pop()??'';
    for(const block of blocks){
      if(!block.includes('event: alertas'))continue;
      const data=block.split('\n').find(line=>line.startsWith('data: '))?.slice(6);
      if(data)onAlerts(JSON.parse(data));
    }
  }
}
export const fetchEvents=()=>jsonRequest('/eventos');
export const createEvent=(data:Record<string,unknown>)=>jsonRequest('/eventos',{method:'POST',body:JSON.stringify(data)});
export const updateEvent=(id:string,data:Record<string,unknown>)=>jsonRequest(`/eventos/${id}`,{method:'PATCH',body:JSON.stringify(data)});
export const deleteEvent=(id:string)=>jsonRequest(`/eventos/${id}`,{method:'DELETE'});
export const fetchApprovals=()=>jsonRequest('/aprobaciones');
export const requestChange=(data:Record<string,unknown>)=>jsonRequest('/aprobaciones',{method:'POST',body:JSON.stringify(data)});
export const resolveApproval=(id:string,approved:boolean)=>jsonRequest(`/aprobaciones/${id}/resolver`,{method:'POST',body:JSON.stringify({approved})});
export const savePreferences=(darkMode:boolean)=>jsonRequest('/usuarios/me/preferencias',{method:'PATCH',body:JSON.stringify({darkMode})});
export const saveProfile=(data:{nombres:string;apellidos:string;fotoPerfil?:string|null;cargo?:string;areaId?:string})=>jsonRequest('/usuarios/me/perfil',{method:'PATCH',body:JSON.stringify(data)});
export const changePassword=(currentPassword:string,newPassword:string)=>jsonRequest('/usuarios/me/password',{method:'PATCH',body:JSON.stringify({currentPassword,newPassword})});
export const fetchRequirements=()=>jsonRequest('/operacion/requerimientos');
export const createRequirement=(data:Record<string,unknown>)=>jsonRequest('/operacion/requerimientos',{method:'POST',body:JSON.stringify(data)});
export const updateRequirement=(id:string,data:Record<string,unknown>)=>jsonRequest(`/operacion/requerimientos/${id}`,{method:'PATCH',body:JSON.stringify(data)});
export const deleteRequirement=(id:string)=>jsonRequest(`/operacion/requerimientos/${id}`,{method:'DELETE'});
export const fetchFlows=()=>jsonRequest('/operacion/flujos');
export const createFlow=(data:Record<string,unknown>)=>jsonRequest('/operacion/flujos',{method:'POST',body:JSON.stringify(data)});
export const forgotPassword=(email:string)=>jsonRequest('/auth/olvide-password',{method:'POST',body:JSON.stringify({email})});
export const resetPassword=(token:string,password:string)=>jsonRequest('/auth/restablecer-password',{method:'POST',body:JSON.stringify({token,password})});
export const fetchCollaboration=(tipo:"grupo"|"canal"|"firma"|"encuesta")=>jsonRequest(`/colaboracion/${tipo}`);
export const createCollaboration=(tipo:"grupo"|"canal"|"firma"|"encuesta",datos:Record<string,unknown>)=>jsonRequest(`/colaboracion/${tipo}`,{method:'POST',body:JSON.stringify(datos)});
export const updateCollaboration=(tipo:"grupo"|"canal"|"firma"|"encuesta",id:string,datos:Record<string,unknown>)=>jsonRequest(`/colaboracion/${tipo}/${id}`,{method:'PATCH',body:JSON.stringify(datos)});
export const fetchGroupInvitations=()=>jsonRequest('/colaboracion/invitaciones/grupos');
export const inviteGroupMember=(groupId:string,usuarioId:string)=>jsonRequest(`/colaboracion/grupo/${groupId}/invitaciones`,{method:'POST',body:JSON.stringify({usuarioId})});
export const respondGroupInvitation=(groupId:string,invitationId:string,respuesta:'Aceptar'|'Rechazar')=>jsonRequest(`/colaboracion/grupo/${groupId}/invitaciones/${invitationId}/responder`,{method:'POST',body:JSON.stringify({respuesta})});
export const globalSearch=(query:string)=>jsonRequest(`/busqueda?q=${encodeURIComponent(query)}`);
export const fetchAuditTrail=()=>jsonRequest('/busqueda/auditoria');
export const fetchNotifications=(archived=false)=>jsonRequest(`/notificaciones?archivadas=${archived}`);
export const readAllNotifications=()=>jsonRequest('/notificaciones/leer-todas',{method:'PATCH'});
export const readNotification=(id:string)=>jsonRequest(`/notificaciones/${id}/leer`,{method:'PATCH'});
export const archiveNotification=(id:string)=>jsonRequest(`/notificaciones/${id}/archivar`,{method:'PATCH'});
export const saveNotificationPreferences=(data:Record<string,boolean>)=>jsonRequest('/notificaciones/preferencias',{method:'PATCH',body:JSON.stringify(data)});
export const fetchTrash=()=>jsonRequest('/admin/papelera');
export const restoreTrash=(id:string,type:string)=>jsonRequest(`/admin/papelera/${id}/restaurar`,{method:'PATCH',body:JSON.stringify({type})});
export const purgeTrash=(id:string,type:string)=>jsonRequest(`/admin/papelera/${id}`,{method:'DELETE',body:JSON.stringify({type})});
export const bulkImport=(rows:Record<string,unknown>[])=>jsonRequest('/admin/importar',{method:'POST',body:JSON.stringify({rows})});
export const updateUserPermissions=(id:string,permissions:Record<string,boolean>)=>jsonRequest(`/admin/usuarios/${id}/permisos`,{method:'PATCH',body:JSON.stringify(permissions)});
export const completeOnboarding=()=>jsonRequest('/admin/onboarding',{method:'PATCH'});
export const addFlowVersion=(id:string,data:Record<string,unknown>)=>jsonRequest(`/operacion/flujos/${id}/versiones`,{method:'POST',body:JSON.stringify(data)});
export const deleteFlow=(id:string)=>jsonRequest(`/operacion/flujos/${id}`,{method:'DELETE'});
export const verifyEmail=(token:string)=>jsonRequest('/auth/verificar-email',{method:'POST',body:JSON.stringify({token})});
export const fetchMySignature=()=>jsonRequest('/colaboracion/firma/perfil/mi-firma');
export const saveMySignature=(firmaData:string)=>jsonRequest('/colaboracion/firma/perfil/mi-firma',{method:'PUT',body:JSON.stringify({firmaData})});
export const signDocument=(id:string,password:string)=>jsonRequest(`/colaboracion/firma/${id}/firmar`,{method:'POST',body:JSON.stringify({password,acepta:true})});
export const rejectDocument=(id:string,password:string,motivo:string)=>jsonRequest(`/colaboracion/firma/${id}/rechazar`,{method:'POST',body:JSON.stringify({password,motivo})});
