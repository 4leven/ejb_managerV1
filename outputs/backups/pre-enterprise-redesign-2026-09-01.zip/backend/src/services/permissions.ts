export type Actor={id:string;areaId:string;cargo:string;rol:string;isSuperAdmin:boolean;permisos?:unknown};
export const hasPermission=(actor:Actor,key:string)=>actor.isSuperAdmin||Boolean((actor.permisos as Record<string,boolean>|null)?.[key]);
export const isManagement=(actor:Actor)=>actor.isSuperAdmin||actor.rol==="Admin"||actor.cargo==="Gerente";
export const canManageArea=(actor:Actor,areaId:string)=>actor.isSuperAdmin||actor.rol==="Admin"||(actor.cargo==="Gerente"&&actor.areaId===areaId);
export const canReadInitiative=(actor:Actor,item:{areaId:string;responsableId?:string|null})=>isManagement(actor)||actor.areaId===item.areaId||actor.id===item.responsableId;
export const canManageInitiative=(actor:Actor,item:{areaId:string;responsableId?:string|null})=>canManageArea(actor,item.areaId)||hasPermission(actor,"editarProyectos")||actor.id===item.responsableId;
export const groupMembers=(data:any,creatorId:string):string[]=>Array.from(new Set([creatorId,...(Array.isArray(data?.miembros)?data.miembros:[])]));
export const canReadPrivateGroup=(actorId:string,data:any,creatorId:string)=>groupMembers(data,creatorId).includes(actorId);
