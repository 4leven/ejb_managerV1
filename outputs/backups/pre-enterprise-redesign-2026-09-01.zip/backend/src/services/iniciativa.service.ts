import { Estado, Esfuerzo, Prisma } from '@prisma/client';
import { prisma } from '../config/db.js';
import { codigo, score } from '../utils/iniciativa.js';

const allowed: Record<Estado, Estado[]> = {
  Pendiente: [Estado.En_evaluacion], En_evaluacion: [Estado.Pendiente, Estado.Priorizado],
  Priorizado: [Estado.En_evaluacion, Estado.En_desarrollo], En_desarrollo: [Estado.Priorizado]
};
export const iniciativaService = {
  async list() {const rows=await prisma.iniciativa.findMany({include:{area:true, objetivo:true, responsable:true,tareas:{include:{responsable:{select:{id:true,nombres:true,apellidos:true,fotoPerfil:true}},comentarios:{include:{usuario:{select:{id:true,nombres:true,apellidos:true,fotoPerfil:true}}},orderBy:{createdAt:'desc'}}},orderBy:{createdAt:'asc'}},progresos:{orderBy:{createdAt:'desc'}},_count:{select:{eventos:true}}}, orderBy:{score:'desc'}});return rows.map(row=>({...row,porcentajeAvance:row.tareas.length?Math.round(row.tareas.filter(task=>task.completada).length/row.tareas.length*100):0}))},
  async create(data:{titulo:string;descripcion:string;cliente?:string;areaId:string;objetivoId?:string;impacto:number;esfuerzo:Esfuerzo;fechaInicio?:Date;fechaFin?:Date;tareas?:string[]}) {
    const attempt = () => prisma.$transaction(async tx => {
      const last = await tx.iniciativa.findFirst({ orderBy:{codigo:'desc'}, select:{codigo:true} });
      const sequence = last ? Number(last.codigo.slice(4)) : 0;
      const {tareas,...initiative}=data;
      return tx.iniciativa.create({data:{...initiative,codigo:codigo(sequence),score:score(data.impacto,data.esfuerzo),tareas:tareas?.length?{create:tareas.map(titulo=>({titulo}))}:undefined},include:{area:true,tareas:true}});
    }, { isolationLevel: Prisma.TransactionIsolationLevel.Serializable });
    try { return await attempt(); }
    catch (error) {
      if (error instanceof Prisma.PrismaClientKnownRequestError && ['P2002','P2034'].includes(error.code)) return attempt();
      throw error;
    }
  },
  async transition(id:string, estado:Estado, responsableId?:string) {
    const current = await prisma.iniciativa.findUniqueOrThrow({where:{id}});
    if (!allowed[current.estado].includes(estado)) throw new Error('Transición de estado no permitida');
    const owner = responsableId ?? current.responsableId;
    if (estado === Estado.Priorizado && !owner) throw new Error('Asigna un responsable antes de priorizar');
    return prisma.iniciativa.update({where:{id},data:{estado,responsableId:owner}});
  },
  progresos:(id:string)=>prisma.progreso.findMany({where:{iniciativaId:id},include:{usuario:{select:{nombres:true,apellidos:true}}},orderBy:{createdAt:'desc'}}),
  appearance:(id:string,icono:string,colorIcono:string)=>prisma.iniciativa.update({where:{id},data:{icono,colorIcono},include:{area:true,objetivo:true,responsable:true}}),
  async addProgreso(id:string,usuarioId:string,porcentaje:number,comentario:string){
    return prisma.$transaction(async tx=>{
      await tx.iniciativa.findUniqueOrThrow({where:{id}});
      const progreso=await tx.progreso.create({data:{iniciativaId:id,usuarioId,porcentaje,comentario},include:{usuario:{select:{nombres:true,apellidos:true}}}});
      await tx.iniciativa.update({where:{id},data:{porcentajeAvance:porcentaje}});
      return progreso;
    });
  }
};
