import { FormEvent, useEffect, useMemo, useRef, useState, type CSSProperties } from "react";
import {
  ArrowRight,
  ArrowLeft,
  Bell,
  BarChart3,
  CalendarDays,
  CheckSquare,
  ClipboardList,
  ChevronDown,
  CircleHelp,
  Clock3,
  Edit3,
  LayoutDashboard,
  Lightbulb,
  LogOut,
  MessageCircle,
  Menu,
  FileText,
  FileSignature,
  Palette,
  Paintbrush,
  PanelLeftClose,
  PanelLeftOpen,
  Plus,
  Search,
  Moon,
  Sun,
  ShieldCheck,
  SlidersHorizontal,
  Sparkles,
  Target,
  Trash2,
  TrendingUp,
  UserCog,
  Users,
  Vote,
  X,
  ZoomIn,
  ZoomOut,
} from "lucide-react";
import {
  addProgreso,
  addInitiativeTask,
  createIniciativa,
  createObjetivo,
  fetchCatalogo,
  fetchConversations,
  fetchAlerts,
  fetchEquipo,
  fetchIniciativas,
  fetchObjetivos,
  fetchProgresos,
  forgotPassword,
  login,
  me,
  register,
  requestChange,
  resetPassword,
  savePortalColor,
  saveInitiativeAppearance,
  saveTeamCargo,
  deleteTeamMember,
  savePreferences,
  updateInitiative,
  updateInitiativeTask,
  deleteInitiative,
} from "./api/iniciativas";
import Messages from "./components/Messages";
import { Approvals, Profile, Timeline } from "./components/ManagerModules";
import { BIReports } from "./components/AnalyticsCalendar";
import { CalendarModule } from "./components/EventCalendar";
import { AreaFlows, Requirements } from "./components/Operations";
import { Surveys } from "./components/CollaborationModules";
import SecureSignature from "./components/SecureSignature";
import ObjectivesModule from "./components/ObjectivesModule";
import { uiAlert, uiConfirm, uiPrompt } from "./utils/dialog";

type Page =
  | "resumen"
  | "iniciativas"
  | "objetivos"
  | "equipo"
  | "mensajes"
  | "cronograma"
  | "calendario"
  | "informes"
  | "requerimientos"
  | "flujos"
  | "firmas"
  | "encuestas"
  | "aprobaciones"
  | "perfil"
  | "ayuda"
  | "personalizacion";
type Estado = "Pendiente" | "En evaluación" | "Priorizado" | "En desarrollo";
type Area = { id: string; nombre: string; colorHex: string };
type User = {
  id: string;
  nombres: string;
  apellidos: string;
  nombreCompleto: string;
  email: string;
  cargo: string;
  rol: string;
  portalColor: string;
  darkMode: boolean;
  fotoPerfil?: string | null;
  estadoMensaje: string;
  isSuperAdmin: boolean;
  area: Area;
};
type Item = {
  id: string;
  codigo: string;
  titulo: string;
  descripcion: string;
  area: string;
  color: string;
  impacto: number;
  esfuerzo: string;
  score: number;
  estado: Estado;
  avance: number;
  responsable: string;
  fecha: string;
  fechaInicio?: string;
  fechaFin?: string;
  fechaActualizacion?: string;
  objetivoId?: string;
  icono?: string;
  colorIcono?: string;
  progresos?: { porcentaje: number; createdAt: string }[];
  tareas: {id:string;titulo:string;estado:string;completada:boolean;comentario?:string|null}[];
};
type Objetivo = {
  id: string;
  nombre: string;
  descripcion?: string;
  _count?: { iniciativas: number };
  progresos?: { id?: string; porcentaje: number; comentario?: string; createdAt: string; usuario?: { nombres: string; apellidos: string; fotoPerfil?: string } }[];
};
type TeamMember = {
  id: string;
  nombres: string;
  apellidos: string;
  email: string;
  cargo: string;
  area: Area;
  isSuperAdmin: boolean;
  fotoPerfil?: string | null;
};
type HelpTopic = { title: string; text: string; detail: string };
type Progress = {
  id: string;
  porcentaje: number;
  comentario: string;
  createdAt: string;
  usuario: { nombres: string; apellidos: string };
};
const statusClass: Record<Estado, string> = {
  Pendiente: "neutral",
  "En evaluación": "amber",
  Priorizado: "purple",
  "En desarrollo": "green",
};
const initials = (value: string) =>
  value
    .split(" ")
    .filter(Boolean)
    .map((x) => x[0])
    .join("")
    .slice(0, 2)
    .toUpperCase();
const mapItem = (r: any): Item => ({
  id: r.id,
  codigo: r.codigo,
  titulo: r.titulo,
  descripcion: r.descripcion,
  area: r.area.nombre,
  color: r.area.colorHex,
  impacto: r.impacto,
  esfuerzo: r.esfuerzo,
  score: Number(r.score),
  estado: r.estado
    .replace("En_evaluacion", "En evaluación")
    .replace("En_desarrollo", "En desarrollo"),
  avance: r.porcentajeAvance,
  responsable: r.responsable
    ? initials(`${r.responsable.nombres} ${r.responsable.apellidos}`)
    : "—",
  fecha: "Ahora",
  fechaInicio: r.fechaInicio,
  fechaFin: r.fechaFin,
  fechaActualizacion: r.fechaActualizacion,
  objetivoId: r.objetivo?.id,
  icono: r.icono,
  colorIcono: r.colorIcono,
  progresos: r.progresos ?? [],
  tareas: r.tareas ?? [],
});

const readableText = (color: string) => {
  const hex = color.replace("#", "");
  if (hex.length !== 6) return "#ffffff";
  const [r, g, b] = [0, 2, 4].map((i) => parseInt(hex.slice(i, i + 2), 16));
  return (r * 299 + g * 587 + b * 114) / 1000 > 150 ? "#0b1830" : "#ffffff";
};

function Access({
  areas,
  onAccess,
}: {
  areas: Area[];
  onAccess: (u: User, t: string) => void;
}) {
  const [mode, setMode] = useState<"register" | "login">("register"),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false);
  const submit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setBusy(true);
    setError("");
    const f = new FormData(e.currentTarget);
    try {
      const data =
        mode === "login"
          ? await login(String(f.get("email")), String(f.get("password")))
          : await register({
              nombres: String(f.get("nombres")),
              apellidos: String(f.get("apellidos")),
              email: String(f.get("email")),
              password: String(f.get("password")),
              areaId: String(f.get("areaId")),
              cargo: String(f.get("cargo")),
            });
      onAccess(data.usuario, data.token);
    } catch (x) {
      setError(x instanceof Error ? x.message : "No se pudo continuar");
    } finally {
      setBusy(false);
    }
  };
  const forgot = async () => {
    const email = await uiPrompt("Recuperar contraseña","",{message:"Escribe tu correo registrado.",placeholder:"correo@empresa.com"});
    if (!email) return;
    const result = await forgotPassword(email);
    if (result.developmentToken) {
      const password = await uiPrompt("Nueva contraseña","",{message:"Modo local: escribe una contraseña de mínimo 8 caracteres."});
      if (password) {
        await resetPassword(result.developmentToken, password);
        await uiAlert("Contraseña actualizada","Ya puedes ingresar con tu nueva contraseña.");
      }
    } else await uiAlert("Solicitud recibida","Si el correo existe, recibirás un enlace de recuperación.");
  };
  return (
    <div className="access-page">
      <section className="access-brand">
        <img
          className="login-logo"
          src="/ejb-manager-logo.svg"
          alt="EJB Manager"
        />
        <div>
          <small>GESTIÓN DE PROYECTOS Y PROGRESOS</small>
          <h1>
            Transformamos ideas
            <br />
            en valor medible.
          </h1>
          <p>
            Propón, evalúa y acelera las iniciativas que hacen avanzar a EJB.
          </p>
        </div>
        <ul>
          <li>
            <ShieldCheck />
            Datos protegidos
          </li>
          <li>
            <Users />
            Trabajo por áreas
          </li>
          <li>
            <Target />
            Prioridad compartida
          </li>
        </ul>
      </section>
      <section className="access-form">
        <div className="access-card">
          <div className="auth-tabs">
            <button
              className={mode === "register" ? "active" : ""}
              onClick={() => setMode("register")}
            >
              Crear cuenta
            </button>
            <button
              className={mode === "login" ? "active" : ""}
              onClick={() => setMode("login")}
            >
              Ingresar
            </button>
          </div>
          <h2>
            {mode === "register"
              ? "Bienvenido a EJB MANAGER"
              : "Qué bueno verte"}
          </h2>
          <p>
            {mode === "register"
              ? "Regístrate con tus datos corporativos."
              : "Ingresa con tu correo y contraseña."}
          </p>
          <form onSubmit={submit}>
            {mode === "register" && (
              <>
                <div className="two-fields">
                  <label>
                    Nombres
                    <input name="nombres" required minLength={2} />
                  </label>
                  <label>
                    Apellidos
                    <input name="apellidos" required minLength={2} />
                  </label>
                </div>
                <label>
                  Área
                  <select name="areaId" required defaultValue="">
                    <option value="" disabled>
                      Selecciona tu área
                    </option>
                    {areas.map((a) => (
                      <option key={a.id} value={a.id}>
                        {a.nombre}
                      </option>
                    ))}
                  </select>
                </label>
                <label>
                  Cargo
                  <select name="cargo" required defaultValue="">
                    <option value="" disabled>
                      Selecciona tu cargo
                    </option>
                    <option>Gerente</option>
                    <option>Asistente</option>
                    <option>Trabajador</option>
                  </select>
                </label>
              </>
            )}
            <label>
              Correo corporativo
              <input name="email" type="email" required />
            </label>
            <label>
              Contraseña
              <input name="password" type="password" required minLength={8} />
            </label>
            {error && <div className="auth-error">{error}</div>}
            <button className="primary auth-submit" disabled={busy}>
              {busy
                ? "Procesando..."
                : mode === "register"
                  ? "Crear mi cuenta"
                  : "Ingresar"}
              <ArrowRight />
            </button>
          </form>
          {mode === "login" && (
            <button className="forgot-link" onClick={forgot}>
              ¿Olvidaste tu contraseña?
            </button>
          )}
        </div>
      </section>
    </div>
  );
}

async function askProjectChange(item: Item, accion: "Editar" | "Eliminar") {
  const motivo = await uiPrompt(`Solicitar ${accion.toLowerCase()} proyecto`,"",{message:"Indica el motivo de la solicitud.",multiline:true});
  if (!motivo) return;
  let payload: Record<string, unknown> | undefined;
  if (accion === "Editar") {
    const titulo = await uiPrompt("Nuevo título",item.titulo);
    const descripcion = await uiPrompt("Nueva descripción",item.descripcion,{multiline:true});
    if (!titulo || !descripcion) return;
    payload = { titulo, descripcion };
  }
  await requestChange({
    tipoEntidad: "Iniciativa",
    entidadId: item.id,
    accion,
    payload,
    motivo,
  });
  await uiAlert("Solicitud enviada","El Gerente del área recibirá la solicitud para su aprobación.");
}
function InitiativeList({
  items,
  onProgress,
  onAppearance,
  onSelect,
  user,
  areas,
  onChanged,
}: {
  items: Item[];
  onProgress: (i: Item) => void;
  onAppearance: (i: Item) => void;
  onSelect: (i: Item) => void;
  user: User;
  areas: Area[];
  onChanged: () => void;
}) {
  const [editItem,setEditItem]=useState<Item|null>(null);
  if (!items.length)
    return (
      <div className="empty-state">
        <div>
          <Lightbulb />
        </div>
        <h3>Aún no hay iniciativas</h3>
        <p>Registra la primera idea para comenzar el portafolio.</p>
      </div>
    );
  return (
    <>
      <div className="list-head">
        <span>INICIATIVA</span>
        <span>PRIORIDAD</span>
        <span>ESTADO</span>
        <span>AVANCE</span>
        <span>ACCIONES</span>
      </div>
      <div className="initiative-list">
        {items.map((i) => (
          <article className="initiative" key={i.id} onClick={()=>onSelect(i)}>
            <div className="initiative-main">
              <div className="area-icon" style={{ background: i.colorIcono ?? i.color, color: readableText(i.colorIcono ?? i.color) }}>
                {i.icono ?? i.area[0]}
              </div>
              <div>
                <div className="code">
                  <i style={{ background: i.color }} />
                  {i.area} · {i.codigo}
                </div>
                <h3>{i.titulo}</h3>
                <p>{i.descripcion}</p>
              </div>
            </div>
            <div className="score">
              <b>{i.score}</b>
              <span>Score</span>
            </div>
            <div>
              <span className={`status ${statusClass[i.estado]}`}>
                <i />
                {i.estado}
              </span>
            </div>
            <div className="progress-cell">
              <div>
                <i style={{ width: `${i.avance}%` }} />
              </div>
              <b>{i.avance}%</b>
            </div>
            <div className="row-actions">
              <button onClick={(e) => {e.stopPropagation();onAppearance(i)}} title="Personalizar icono">
                <Paintbrush />
              </button>
              <button onClick={(e) => {e.stopPropagation();onProgress(i)}} title="Agregar progreso">
                <TrendingUp />
              </button>
              {(user.isSuperAdmin||(user.cargo==="Gerente"&&user.area.nombre===i.area))&&<button
                onClick={(e) => {e.stopPropagation();setEditItem(i)}}
                title="Editar iniciativa"
              >
                <Edit3 />
              </button>}
              {user.isSuperAdmin&&<button
                onClick={async(e) => {e.stopPropagation();if(await uiConfirm("Eliminar iniciativa",`¿Deseas eliminar definitivamente ${i.codigo}?`)){await deleteInitiative(i.id);onChanged()}}}
                title="Eliminar iniciativa"
              >
                <Trash2 />
              </button>}
            </div>
          </article>
        ))}
      </div>
      {editItem&&<div className="overlay"><form className="event-modal initiative-edit-modal" onSubmit={async(e)=>{e.preventDefault();const f=new FormData(e.currentTarget);await updateInitiative(editItem.id,{titulo:String(f.get("titulo")),descripcion:String(f.get("descripcion")),areaId:String(f.get("areaId"))});await saveInitiativeAppearance(editItem.id,{icono:String(f.get("icono")),colorIcono:String(f.get("colorIcono"))});setEditItem(null);onChanged()}}><button type="button" className="close" onClick={()=>setEditItem(null)}><X/></button><Edit3/><h2>Editar iniciativa</h2><p>{editItem.codigo} · Solo jefatura del área o administración global.</p><label>Área<select name="areaId" defaultValue={areas.find(a=>a.nombre===editItem.area)?.id}>{areas.map(a=><option key={a.id} value={a.id}>{a.nombre}</option>)}</select></label><label>Título<input name="titulo" defaultValue={editItem.titulo} required minLength={3}/></label><label>Descripción<textarea name="descripcion" defaultValue={editItem.descripcion} required minLength={10}/></label><div className="initiative-icon-editor"><div className="icon-edit-preview" style={{background:editItem.colorIcono??editItem.color,color:readableText(editItem.colorIcono??editItem.color)}}>{editItem.icono??editItem.area.slice(0,2).toUpperCase()}</div><label>Letras o emoji<input name="icono" defaultValue={editItem.icono??editItem.area.slice(0,2).toUpperCase()} maxLength={12} required/></label><label>Color del icono<input name="colorIcono" type="color" defaultValue={editItem.colorIcono??editItem.color}/></label></div><div className="modal-actions"><button type="button" onClick={()=>setEditItem(null)}>Cancelar</button><button className="primary">Guardar cambios</button></div></form></div>}
    </>
  );
}

function App() {
  const [areas, setAreas] = useState<Area[]>([]),
    [user, setUser] = useState<User | null>(null),
    [booting, setBooting] = useState(true),
    [page, setPage] = useState<Page>("resumen"),
    [items, setItems] = useState<Item[]>([]),
    [objetivos, setObjetivos] = useState<Objetivo[]>([]),
    [team, setTeam] = useState<TeamMember[]>([]),
    [query, setQuery] = useState(""),
    [area, setArea] = useState("Todas"),
    [statusFilter, setStatusFilter] = useState("Todos"),
    [effortFilter, setEffortFilter] = useState("Todos"),
    [sortFilter, setSortFilter] = useState("score"),
    [filtersOpen, setFiltersOpen] = useState(false),
    [sidebarCollapsed, setSidebarCollapsed] = useState(false),
    [sidebarScale, setSidebarScale] = useState(()=>Number(localStorage.getItem("ejb_sidebar_scale")||1)),
    [mainScale, setMainScale] = useState(()=>Number(localStorage.getItem("ejb_main_scale")||1)),
    [mobileMenuOpen, setMobileMenuOpen] = useState(false),
    [selectedItem, setSelectedItem] = useState<Item | null>(null),
    [appearanceItem, setAppearanceItem] = useState<Item | null>(null),
    [helpTopic, setHelpTopic] = useState<HelpTopic | null>(null),
    [modal, setModal] = useState(false),
    [progressItem, setProgressItem] = useState<Item | null>(null),
    [history, setHistory] = useState<Progress[]>([]),
    [alerts, setAlerts] = useState<any[]>([]),
    [notificationsOpen, setNotificationsOpen] = useState(false),
    [userMenuOpen, setUserMenuOpen] = useState(false),
    [toast, setToast] = useState(""),
    [unreadMessages,setUnreadMessages]=useState(0),
    [messageNotice,setMessageNotice]=useState<{name:string;message:string;photo?:string|null}|null>(null);
  const zoomZone = useRef<"sidebar"|"main">("main");
  const notificationAudio = useRef<AudioContext|null>(null),lastAlertCount=useRef(0),alertsInitialized=useRef(false),lastAlertSignature=useRef(""),currentAlerts=useRef<any[]>([]),alertsSoundedAfterUnlock=useRef(false),messageNoticeTimer=useRef<ReturnType<typeof setTimeout>|null>(null),lastMessageNotice=useRef({key:"",at:0});
  const alertSignature=(rows:any[])=>rows.map(row=>`${row.type}|${row.initiativeId}|${row.title}|${row.message}`).sort().join("::");
  const playNotificationSound=(kind:"message"|"alert")=>{const context=notificationAudio.current;if(!context||context.state!=="running")return;const now=context.currentTime,tones=kind==="alert"?[{frequency:660,start:0,duration:.16},{frequency:880,start:.2,duration:.2}]:[{frequency:740,start:0,duration:.23}];tones.forEach(tone=>{const oscillator=context.createOscillator(),gain=context.createGain(),start=now+tone.start;oscillator.type=kind==="message"?"sine":"triangle";oscillator.frequency.setValueAtTime(tone.frequency,start);oscillator.frequency.exponentialRampToValueAtTime(kind==="message"?980:tone.frequency*1.12,start+tone.duration*.65);gain.gain.setValueAtTime(.0001,start);gain.gain.exponentialRampToValueAtTime(kind==="alert"?.15:.12,start+.018);gain.gain.exponentialRampToValueAtTime(.0001,start+tone.duration);oscillator.connect(gain);gain.connect(context.destination);oscillator.start(start);oscillator.stop(start+tone.duration+.02)})};
  const showIncomingMessage=(name:string,message:string,photo?:string|null)=>{const now=Date.now(),key=`${name}|${message}`;if(lastMessageNotice.current.key===key&&now-lastMessageNotice.current.at<6000)return;lastMessageNotice.current={key,at:now};setMessageNotice({name,message,photo});playNotificationSound("message");if(messageNoticeTimer.current)clearTimeout(messageNoticeTimer.current);messageNoticeTimer.current=setTimeout(()=>setMessageNotice(null),4000);if("Notification" in window&&Notification.permission==="granted"){const notification=new Notification(`Mensaje de ${name}`,{body:message,icon:photo||"/ejb-manager-isotipo.svg",badge:"/ejb-manager-isotipo.svg",tag:`ejb-message-${name}`});notification.onclick=()=>{window.focus();setPage("mensajes");notification.close()}}};
  const reloadItems=()=>fetchIniciativas().then((r:any[])=>setItems(r.map(mapItem)));
  const toggleTheme=async()=>{if(!user)return;const darkMode=!user.darkMode;await savePreferences(darkMode);setUser({...user,darkMode})};
  useEffect(() => {
    fetchCatalogo()
      .then((c) => setAreas(c.areas))
      .finally(() => setBooting(false));
    if (localStorage.getItem("ejb_token"))
      me()
        .then(setUser)
        .catch(() => localStorage.removeItem("ejb_token"));
  }, []);
  useEffect(() => {
    if (!user) return;
    fetchIniciativas().then((r: any[]) => setItems(r.map(mapItem)));
    fetchObjetivos().then(setObjetivos);
    fetchEquipo().then(setTeam);
    fetchAlerts().then(rows=>{setAlerts(rows);currentAlerts.current=rows;lastAlertCount.current=rows.length;lastAlertSignature.current=alertSignature(rows);alertsInitialized.current=true});
  }, [user]);
  useEffect(() => {
    if (!user) return;
    const timer = window.setInterval(() => fetchAlerts().then(rows=>{const signature=alertSignature(rows);if(alertsInitialized.current&&signature!==lastAlertSignature.current&&rows.some((row:any)=>!lastAlertSignature.current.includes(`${row.type}|${row.initiativeId}|${row.title}|${row.message}`)))playNotificationSound("alert");lastAlertCount.current=rows.length;lastAlertSignature.current=signature;currentAlerts.current=rows;alertsInitialized.current=true;setAlerts(rows)}).catch(() => undefined), 10000);
    return () => window.clearInterval(timer);
  }, [user?.id]);
  useEffect(()=>{const unlock=async()=>{if(!notificationAudio.current)notificationAudio.current=new AudioContext();await notificationAudio.current.resume().catch(()=>undefined);if(currentAlerts.current.length&&!alertsSoundedAfterUnlock.current){alertsSoundedAfterUnlock.current=true;playNotificationSound("alert")}if("Notification" in window&&Notification.permission==="default")Notification.requestPermission().catch(()=>undefined)};window.addEventListener("pointerdown",unlock,{once:true});return()=>window.removeEventListener("pointerdown",unlock)},[]);
  useEffect(() => {
    document.documentElement.style.setProperty(
      "--portal-color",
      user?.portalColor ?? "#0B2347",
    );
  }, [user?.portalColor]);
  useEffect(() => {
    document.documentElement.classList.toggle("dark", Boolean(user?.darkMode));
    const color = user?.portalColor ?? "#0B2347",
      rgb = [1, 3, 5].map((i) => parseInt(color.slice(i, i + 2), 16)),
      luminance = (rgb[0] * 299 + rgb[1] * 587 + rgb[2] * 114) / 1000;
    document.documentElement.style.setProperty(
      "--portal-on-color",
      luminance > 150 ? "#0b1830" : "#ffffff",
    );
  }, [user?.darkMode, user?.portalColor]);
  useEffect(()=>{localStorage.setItem("ejb_sidebar_scale",String(sidebarScale))},[sidebarScale]);
  useEffect(()=>{localStorage.setItem("ejb_main_scale",String(mainScale))},[mainScale]);
  useEffect(()=>{
    const adjust=(direction:number)=>{
      const update=(value:number)=>Math.min(1.3,Math.max(.7,+(value+direction*.05).toFixed(2)));
      if(zoomZone.current==="sidebar") setSidebarScale(update);
      else setMainScale(update);
    };
    const onWheel=(event:WheelEvent)=>{
      if(!event.ctrlKey)return;
      event.preventDefault();
      adjust(event.deltaY<0?1:-1);
    };
    const onKey=(event:KeyboardEvent)=>{
      if(!event.ctrlKey)return;
      if(event.key==="0"){
        event.preventDefault();
        zoomZone.current==="sidebar"?setSidebarScale(1):setMainScale(1);
      }else if(["+","=","Add"].includes(event.key)){
        event.preventDefault();adjust(1);
      }else if(["-","_","Subtract"].includes(event.key)){
        event.preventDefault();adjust(-1);
      }
    };
    window.addEventListener("wheel",onWheel,{passive:false});
    window.addEventListener("keydown",onKey);
    return()=>{window.removeEventListener("wheel",onWheel);window.removeEventListener("keydown",onKey)};
  },[]);
  useEffect(()=>{if(!toast)return;const timer=setTimeout(()=>setToast(""),toast.length>55?2000:1500);return()=>clearTimeout(timer)},[toast]);
  useEffect(()=>{if(!user)return;let initialized=false,lastUnread=0;const loadMessages=async()=>{const rows=await fetchConversations();const total=rows.reduce((sum:number,row:any)=>sum+Number(row.unread||0),0);if(initialized&&total>lastUnread){const sender=rows.find((row:any)=>row.unread>0);if(sender)showIncomingMessage(`${sender.nombres} ${sender.apellidos}`,sender.lastMessage?.contenido??"Nuevo mensaje",sender.fotoPerfil)}lastUnread=total;setUnreadMessages(total);initialized=true};loadMessages();const timer=setInterval(loadMessages,3500);return()=>clearInterval(timer)},[user?.id,page]);
  const filtered = useMemo(
    () =>
      items.filter(
        (i) =>
          (area === "Todas" || i.area === area) &&
          (statusFilter === "Todos" || i.estado === statusFilter) &&
          (effortFilter === "Todos" || i.esfuerzo === effortFilter) &&
          `${i.titulo} ${i.codigo}`.toLowerCase().includes(query.toLowerCase()),
      ).sort((a,b)=>sortFilter==="avance"?b.avance-a.avance:sortFilter==="recientes"?b.codigo.localeCompare(a.codigo):b.score-a.score),
    [items, query, area, statusFilter, effortFilter, sortFilter],
  );
  const openProgress = async (i: Item) => {
    setProgressItem(i);
    setHistory(await fetchProgresos(i.id));
  };
  const customizeInitiative = async (i: Item) => {
    setAppearanceItem(i);
  };
  const changeTeamCargo = async (member: TeamMember, cargo: string) => {
    await saveTeamCargo(member.id, cargo);
    setTeam((rows)=>rows.map((row)=>row.id===member.id?{...row,cargo}:row));
    setToast(`${member.nombres} ahora tiene el rol ${cargo}`);
  };
  const addInitiative = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const f = new FormData(e.currentTarget),
      selected = areas.find((a) => a.nombre === String(f.get("area")));
    if (!selected) return;
    try {
      const r = await createIniciativa({
        titulo: String(f.get("titulo")),
        descripcion: String(f.get("descripcion")),
        areaId: selected.id,
        impacto: Number(f.get("impacto")),
        esfuerzo: String(f.get("esfuerzo")),
        fechaInicio: String(f.get("fechaInicio") || "") || undefined,
        fechaFin: String(f.get("fechaFin") || "") || undefined,
        tareas: String(f.get("tareas")||"").split("\n").map(task=>task.trim()).filter(Boolean),
      });
      setItems((v) => [mapItem(r), ...v]);
      setModal(false);
      setToast("Iniciativa guardada como Pendiente");
    } catch (x) {
      setToast(x instanceof Error ? x.message : "No se pudo guardar");
    }
  };
  const addProgress = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!progressItem) return;
    const f = new FormData(e.currentTarget),
      porcentaje = Number(f.get("porcentaje"));
    const p = await addProgreso(progressItem.id, {
      porcentaje,
      comentario: String(f.get("comentario")),
    });
    setHistory((v) => [p, ...v]);
    setItems((v) =>
      v.map((i) =>
        i.id === progressItem.id ? { ...i, avance: porcentaje } : i,
      ),
    );
    setProgressItem({ ...progressItem, avance: porcentaje });
    const nextAlerts=await fetchAlerts();setAlerts(nextAlerts);currentAlerts.current=nextAlerts;lastAlertCount.current=nextAlerts.length;lastAlertSignature.current=alertSignature(nextAlerts);
    setToast(porcentaje >= 100 ? "Tarea completada y notificaciones actualizadas" : "Progreso registrado");
  };
  const addGoal = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    const goal = await createObjetivo({
      nombre: String(f.get("nombre")),
      descripcion: String(f.get("descripcion")),
    });
    setObjetivos((v) => [goal, ...v]);
    e.currentTarget.reset();
    setToast("Objetivo creado");
  };
  const askGoalChange = async (
    goal: Objetivo,
    accion: "Editar" | "Eliminar",
  ) => {
    if (user?.isSuperAdmin) {
      if (accion === "Eliminar") {
        if (!await uiConfirm("Eliminar objetivo",`¿Deseas eliminar definitivamente “${goal.nombre}”?`)) return;
        await requestChange({tipoEntidad:"Objetivo",entidadId:goal.id,accion,motivo:"Acción directa de administración global"});
        setObjetivos((value)=>value.filter(item=>item.id!==goal.id));
        setToast("Objetivo eliminado");
        return;
      }
      const nombre=await uiPrompt("Editar objetivo",goal.nombre,{message:"Actualiza el nombre del objetivo."});
      if(!nombre)return;
      const descripcion=await uiPrompt("Descripción del objetivo",goal.descripcion??"",{message:"Actualiza la descripción estratégica.",multiline:true});
      if(descripcion===null)return;
      await requestChange({tipoEntidad:"Objetivo",entidadId:goal.id,accion,payload:{nombre,descripcion},motivo:"Edición directa de administración global"});
      setObjetivos((value)=>value.map(item=>item.id===goal.id?{...item,nombre,descripcion}:item));
      setToast("Objetivo actualizado");
      return;
    }
    const motivo = await uiPrompt(`Solicitar ${accion.toLowerCase()} objetivo`,"",{message:"Indica el motivo de la solicitud.",multiline:true});
    if (!motivo) return;
    let payload: Record<string, unknown> | undefined;
    if (accion === "Editar") {
      const nombre = await uiPrompt("Nuevo nombre",goal.nombre);
      const descripcion = await uiPrompt("Nueva descripción",goal.descripcion??"",{multiline:true});
      if (!nombre) return;
      payload = { nombre, descripcion };
    }
    await requestChange({
      tipoEntidad: "Objetivo",
      entidadId: goal.id,
      accion,
      payload,
      motivo,
    });
    setToast("Solicitud enviada para aprobación");
  };
  const changeColor = async (color: string) => {
    await savePortalColor(color);
    setUser((u) => (u ? { ...u, portalColor: color } : u));
    setToast("Color del portal actualizado");
  };
  const access = (u: User, t: string) => {
    localStorage.setItem("ejb_token", t);
    setUser(u);
  };
  const logout = () => {
    localStorage.removeItem("ejb_token");
    setUser(null);
  };
  if (booting)
    return (
      <div className="loading">
        <div className="access-logo">E</div>Cargando EJB Hub…
      </div>
    );
  if (!user) return <Access areas={areas} onAccess={access} />;
  const titles: Record<Page, [string, string]> = {
    resumen: [
      "Resumen del portafolio",
      "Una vista clara de lo que estamos construyendo.",
    ],
    iniciativas: [
      "Proyectos",
      "Registra, prioriza y actualiza el avance de cada proyecto.",
    ],
    objetivos: [
      "Objetivos de negocio",
      "Define hacia dónde debe apuntar la gestión.",
    ],
    equipo: ["Equipo EJB", "Personas registradas, áreas y cargos."],
    mensajes: ["Mensajes", "Conversaciones privadas entre compañeros."],
    cronograma: [
      "Cronograma y alertas",
      "Duración, avance diario y retrasos de proyectos.",
    ],
    calendario: ["Calendario del equipo", "Organiza eventos, responsables y prioridades por área."],
    informes: ["Informes BI", "Estadísticas avanzadas, trazabilidad y planificación ejecutiva."],
    requerimientos: ["Requerimientos Administración", "Solicita y da seguimiento a los recursos que necesita tu área."],
    flujos: ["Flujos de Áreas", "Documenta, comparte y previsualiza procesos de trabajo en PDF."],
    firmas: ["Firma Electrónica", "Carga, revisa y firma documentos internos con trazabilidad."],
    encuestas: ["Encuestas EJB", "Consulta al equipo y visualiza los resultados en tiempo real."],
    aprobaciones: [
      "Aprobaciones",
      "Solicitudes de edición y eliminación de tu área.",
    ],
    perfil: ["Mi perfil", "Actualiza tus datos, foto y preferencias."],
    ayuda: ["Centro de ayuda", "Respuestas rápidas para usar EJB MANAGER."],
    personalizacion: [
      "Personaliza tu portal",
      "Elige el color que mejor represente tu espacio.",
    ],
  };
  return (
    <div className={`shell ${sidebarCollapsed ? "sidebar-collapsed" : ""} ${mobileMenuOpen?"mobile-menu-open":""}`} style={{"--sidebar-scale":sidebarScale,"--main-scale":mainScale,"--main-scale-inverse":1/mainScale} as CSSProperties}>
      <aside onPointerEnter={()=>{zoomZone.current="sidebar"}} onFocusCapture={()=>{zoomZone.current="sidebar"}}>
        <button className="sidebar-toggle" onClick={()=>setSidebarCollapsed((v)=>!v)} title={sidebarCollapsed?"Abrir menú":"Cerrar menú"}>
          {sidebarCollapsed?<PanelLeftOpen/>:<PanelLeftClose/>}
        </button>
        <button
          type="button"
          className="brand"
          aria-label="Ir al resumen"
          title="Volver al inicio"
          onClick={() => {
            setPage("resumen");
            setMobileMenuOpen(false);
            setNotificationsOpen(false);
            window.scrollTo({ top: 0, behavior: "smooth" });
          }}
        >
          <img className="brand-full" src="/ejb-manager-logo.svg" alt="EJB Manager" />
          <img className="brand-compact" src="/ejb-manager-isotipo.svg" alt="EJB" />
        </button>
        <div className="sidebar-zoom"><button onClick={()=>setSidebarScale(v=>Math.max(.82,+(v-.06).toFixed(2)))} title="Reducir menú"><ZoomOut/></button><span>{Math.round(sidebarScale*100)}%</span><button onClick={()=>setSidebarScale(v=>Math.min(1.18,+(v+.06).toFixed(2)))} title="Ampliar menú"><ZoomIn/></button></div>
        <nav onClickCapture={()=>setMobileMenuOpen(false)}>
          <button
            className={page === "resumen" ? "active" : ""}
            onClick={() => setPage("resumen")}
          >
            <LayoutDashboard />
            Resumen
          </button>
          <button
            className={page === "iniciativas" ? "active" : ""}
            onClick={() => setPage("iniciativas")}
          >
            <Lightbulb />
            Proyectos<span>{items.length}</span>
          </button>
          <button
            className={page === "objetivos" ? "active" : ""}
            onClick={() => setPage("objetivos")}
          >
            <Target />
            Objetivos
          </button>
          <button
            className={page === "equipo" ? "active" : ""}
            onClick={() => setPage("equipo")}
          >
            <Users />
            Equipo
          </button>
          <button
            className={page === "mensajes" ? "active" : ""}
            onClick={() => {setPage("mensajes");setMessageNotice(null)}}
          >
            <MessageCircle />
            Mensajes{unreadMessages>0&&<span>{unreadMessages}</span>}
          </button>
          <button
            className={page === "cronograma" ? "active" : ""}
            onClick={() => setPage("cronograma")}
          >
            <CalendarDays />
            Cronograma
          </button>
          <button className={page === "calendario" ? "active" : ""} onClick={() => setPage("calendario")}>
            <CalendarDays /> Calendario
          </button>
          <button className={page === "informes" ? "active" : ""} onClick={() => setPage("informes")}>
            <BarChart3 /> Informes BI
          </button>
          <button className={page === "requerimientos" ? "active" : ""} onClick={() => {setPage("requerimientos");setMobileMenuOpen(false)}}><ClipboardList/>Requerimientos</button>
          <button className={page === "flujos" ? "active" : ""} onClick={() => {setPage("flujos");setMobileMenuOpen(false)}}><FileText/>Flujos de Áreas</button>
          <button className={page === "firmas" ? "active" : ""} onClick={() => {setPage("firmas");setMobileMenuOpen(false)}}><FileSignature/>Firma Electrónica</button>
          <button className={page === "encuestas" ? "active" : ""} onClick={() => {setPage("encuestas");setMobileMenuOpen(false)}}><Vote/>Encuestas</button>
          {(user.cargo === "Gerente" || user.isSuperAdmin) && (
            <button
              className={page === "aprobaciones" ? "active" : ""}
              onClick={() => setPage("aprobaciones")}
            >
              <CheckSquare />
              Aprobaciones
            </button>
          )}
          <button
            className={page === "personalizacion" ? "active" : ""}
            onClick={() => setPage("personalizacion")}
          >
            <Palette />
            Personalización
          </button>
        </nav>
        <div className="nav-foot">
          <button onClick={() => setPage("ayuda")}>
            <CircleHelp />
            Centro de ayuda
          </button>
          <button
            className="user"
            onClick={() => setUserMenuOpen((v) => !v)}
            aria-expanded={userMenuOpen}
          >
            <div>
              {user.fotoPerfil ? (
                <img src={user.fotoPerfil} />
              ) : (
                initials(user.nombreCompleto)
              )}
            </div>
            <p>
              <b>{user.nombreCompleto}</b>
              <small>
                {user.cargo} · {user.area.nombre}
              </small>
            </p>
            <ChevronDown />
          </button>
          {userMenuOpen && (
            <div className="user-menu">
              <button
                onClick={() => {
                  setPage("perfil");
                  setUserMenuOpen(false);
                }}
              >
                <UserCog />
                Mi perfil
              </button>
              <button
                onClick={() => {
                  setPage("personalizacion");
                  setUserMenuOpen(false);
                }}
              >
                <Palette />
                Apariencia
              </button>
              <button onClick={logout}>
                <LogOut />
                Cerrar sesión
              </button>
            </div>
          )}
          <button onClick={() => setPage("perfil")}>
            <UserCog />
            Editar perfil
          </button>
          <button className="logout" onClick={logout}>
            <LogOut />
            Cerrar sesión
          </button>
          <div className="app-version"><span>EJB MANAGER</span><b>V. 0.3.2</b></div>
        </div>
      </aside>
      <main onPointerEnter={()=>{zoomZone.current="main"}} onFocusCapture={()=>{zoomZone.current="main"}}>
        <div className="main-panel-inner">
        <header>
          <button className="mobile-menu-button" onClick={()=>setMobileMenuOpen((v)=>!v)}><Menu/></button>
          <div className="mobile-brand">
            EJB <b>MANAGER</b>
          </div>
          <div className="search">
            <Search />
            <input
              placeholder="Buscar iniciativas..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
            />
          </div>
          <button className="header-theme" onClick={toggleTheme} aria-label={user.darkMode?"Activar modo claro":"Activar modo oscuro"} title={user.darkMode?"Modo claro":"Modo oscuro"}>
            {user.darkMode?<Sun/>:<Moon/>}<span>{user.darkMode?"Claro":"Oscuro"}</span>
          </button>
          <button
            className="icon"
            onClick={() => setNotificationsOpen((v) => !v)}
            aria-label="Ver alertas"
            aria-expanded={notificationsOpen}
          >
            <Bell />
            {alerts.length > 0 && <i />}
          </button>
          {notificationsOpen && (
            <div className="notifications-popover">
              <div>
                <b>Notificaciones</b>
                <button onClick={() => setNotificationsOpen(false)}>
                  <X />
                </button>
              </div>
              {alerts.map((alert, index) => (
                <button
                  key={index}
                  className={alert.severity}
                  onClick={() => {
                    setPage("cronograma");
                    setNotificationsOpen(false);
                  }}
                >
                  <span>{alert.type === "completado" ? "✓" : "!"}</span>
                  <p>
                    <b>{alert.title}</b>
                    <small>{alert.message}</small>
                  </p>
                </button>
              ))}
              {!alerts.length && (
                <div className="notifications-empty">
                  <Bell />
                  <b>Todo al día</b>
                  <small>No tienes alertas pendientes.</small>
                </div>
              )}
              <button
                className="view-all"
                onClick={() => {
                  setPage("cronograma");
                  setNotificationsOpen(false);
                }}
              >
                Ver cronograma y alertas <ArrowRight />
              </button>
            </div>
          )}
          <button className="primary" onClick={() => setModal(true)}>
            <Plus />
            Nueva iniciativa
          </button>
        </header>
        <section className="content">
          <div className="eyebrow">
            <Sparkles /> EJB MANAGER
          </div>
          <div className="title-row">
            <div>
              {page !== "resumen" && (
                <button
                  className="back-button"
                  onClick={() => setPage("resumen")}
                >
                  <ArrowLeft />
                  Volver al resumen
                </button>
              )}
              <h1>{titles[page][0]}</h1>
              <p>{titles[page][1]}</p>
            </div>
            <div className="updated">
              <i /> PostgreSQL conectado
            </div>
          </div>
          {page === "resumen" && (
            <>
              <div className="stats">
                <article>
                  <small>INICIATIVAS</small>
                  <strong>{items.length}</strong>
                  <span>
                    {items.length ? "en portafolio" : "Sin registros"}
                  </span>
                </article>
                <article>
                  <small>EN DESARROLLO</small>
                  <strong>
                    {items.filter((i) => i.estado === "En desarrollo").length}
                  </strong>
                  <span>proyectos activos</span>
                </article>
                <article>
                  <small>AVANCE PROMEDIO</small>
                  <strong>
                    {items.length
                      ? Math.round(
                          items.reduce((s, i) => s + i.avance, 0) /
                            items.length,
                        )
                      : 0}
                    %
                  </strong>
                  <span>actualizado por el equipo</span>
                </article>
                <article className="highlight">
                  <small>OBJETIVOS</small>
                  <strong>{objetivos.length}</strong>
                  <span>líneas estratégicas</span>
                </article>
              </div>
              <div className="bi-grid">
                <article className="bi-card portfolio-health">
                  <div className="bi-heading">
                    <div><small>RENDIMIENTO</small><h3>Salud del portafolio</h3></div>
                    <span>Actualizado ahora</span>
                  </div>
                  <div className="health-body">
                    <div className="donut" style={{ "--value": `${items.length ? Math.round(items.reduce((s, i) => s + i.avance, 0) / items.length) : 0}%` } as CSSProperties}>
                      <div><strong>{items.length ? Math.round(items.reduce((s, i) => s + i.avance, 0) / items.length) : 0}%</strong><small>avance</small></div>
                    </div>
                    <div className="health-legend">
                      {(["Pendiente", "En evaluación", "Priorizado", "En desarrollo"] as Estado[]).map((status) => {
                        const count = items.filter((i) => i.estado === status).length;
                        return <div key={status}><span><i className={statusClass[status]} />{status}</span><b>{count}</b></div>;
                      })}
                    </div>
                  </div>
                </article>
                <article className="bi-card area-performance">
                  <div className="bi-heading">
                    <div><small>AVANCE POR ÁREA</small><h3>Participación de los equipos</h3></div>
                    <span>{areas.length} áreas</span>
                  </div>
                  <div className="area-bars">
                    {areas.map((a) => {
                      const rows = items.filter((i) => i.area === a.nombre);
                      const value = rows.length ? Math.round(rows.reduce((s, i) => s + i.avance, 0) / rows.length) : 0;
                      return <div key={a.id}><span>{a.nombre}<b>{value}%</b></span><div><i style={{ width: `${value}%`, background: a.colorHex }} /></div></div>;
                    })}
                  </div>
                </article>
              </div>
              <SectionTools areas={areas} area={area} setArea={setArea} open={filtersOpen} setOpen={setFiltersOpen} status={statusFilter} setStatus={setStatusFilter} effort={effortFilter} setEffort={setEffortFilter} sort={sortFilter} setSort={setSortFilter} />
              <InitiativeList
                items={filtered.slice(0, 5)}
                onProgress={openProgress}
                onAppearance={customizeInitiative}
                onSelect={setSelectedItem}
                user={user}
                areas={areas}
                onChanged={reloadItems}
              />
            </>
          )}
          {page === "iniciativas" && (
            <>
              <div className="module-actions">
                <SectionTools areas={areas} area={area} setArea={setArea} open={filtersOpen} setOpen={setFiltersOpen} status={statusFilter} setStatus={setStatusFilter} effort={effortFilter} setEffort={setEffortFilter} sort={sortFilter} setSort={setSortFilter} />
                <button className="primary" onClick={() => setModal(true)}>
                  <Plus />
                  Registrar iniciativa
                </button>
              </div>
              <InitiativeList items={filtered} onProgress={openProgress} onAppearance={customizeInitiative} onSelect={setSelectedItem} user={user} areas={areas} onChanged={reloadItems} />
            </>
          )}
          {page === "objetivos" && (
            <ObjectivesModule objetivos={objetivos} items={items} isSuperAdmin={Boolean(user.isSuperAdmin)} onCreate={addGoal} onChange={askGoalChange}/>
          )}
          {page === "equipo" && (
            <div className="team-grid">
              {team.map((m) => (
                <article className="team-card" key={m.id}>
                  <div style={{ background: m.area.colorHex, color: readableText(m.area.colorHex) }}>{m.fotoPerfil?<img src={m.fotoPerfil} alt={`Foto de ${m.nombres} ${m.apellidos}`}/>:initials(`${m.nombres} ${m.apellidos}`)}</div>
                  <h3>
                    {m.nombres} {m.apellidos}
                  </h3>
                  <p>{m.email}</p>
                  {user.isSuperAdmin ? <><select className="team-role" value={m.cargo} onChange={(e)=>changeTeamCargo(m,e.target.value)}><option>Trabajador</option><option>Asistente</option><option>Gerente</option></select>{!m.isSuperAdmin&&<button className="delete-profile" onClick={async()=>{if(await uiConfirm("Eliminar perfil",`¿Deseas eliminar el perfil de ${m.nombres}?`)){await deleteTeamMember(m.id);setTeam(v=>v.filter(x=>x.id!==m.id));setToast("Perfil eliminado")}}}>Eliminar perfil</button>}</> : <span>{m.cargo}</span>}
                  <small>{m.area.nombre}</small>
                </article>
              ))}
            </div>
          )}
          {page === "mensajes" && <Messages currentUserId={user.id} currentStatus={user.estadoMensaje} onStatusChange={(estadoMensaje)=>setUser({...user,estadoMensaje})} onIncomingMessage={showIncomingMessage} />}
          {page === "cronograma" && <Timeline items={items} onBack={() => setPage("resumen")} />}
          {page === "calendario" && <CalendarModule areas={areas} team={team} items={items} currentUserId={user.id} />}
          {page === "informes" && <BIReports items={items} areas={areas} />}
          {page === "requerimientos" && <Requirements user={user} />}
          {page === "flujos" && <AreaFlows />}
          {page === "firmas" && <SecureSignature user={user} team={team} />}
          {page === "encuestas" && <Surveys user={user} />}
          {page === "aprobaciones" && <Approvals user={user} />}
          {page === "perfil" && (
            <Profile user={user} onUpdate={setUser} areas={areas} />
          )}
          {page === "ayuda" && (
            <div className="help-grid">
              <Help
                title="¿Cómo registro una iniciativa?"
                text="Usa Nueva iniciativa, completa impacto y esfuerzo. Se creará como Pendiente."
                detail="Selecciona Nueva iniciativa en la parte superior. Escribe título y descripción, elige el área, impacto, esfuerzo y fechas estimadas. Al guardar se generará automáticamente el código INV-XXX y quedará lista para evaluación."
                onOpen={setHelpTopic}
              />
              <Help
                title="¿Cómo actualizo un proyecto?"
                text="En Iniciativas selecciona Agregar progreso, indica porcentaje y deja un comentario."
                detail="Abre Proyectos y pulsa el icono de gráfico ascendente. Mueve el porcentaje, describe lo completado y guarda. Cada actualización conserva autor, fecha y comentario en el historial."
                onOpen={setHelpTopic}
              />
              <Help
                title="¿Cómo se calcula el score?"
                text="Impacto dividido entre el peso del esfuerzo, multiplicado por diez."
                detail="El sistema asigna un peso al esfuerzo: Bajo 1, Medio 2 y Alto 4. El score se calcula como impacto dividido por ese peso, multiplicado por diez. Un score mayor ayuda a identificar oportunidades prioritarias."
                onOpen={setHelpTopic}
              />
              <Help
                title="¿Dónde están mis datos?"
                text="Los perfiles, proyectos y progresos se guardan en PostgreSQL, no en el navegador."
                detail="PostgreSQL conserva usuarios, áreas, proyectos, objetivos, progresos, mensajes, adjuntos, preferencias, iconos y solicitudes. El navegador solo guarda temporalmente el token de sesión."
                onOpen={setHelpTopic}
              />
            </div>
          )}
          {page === "personalizacion" && (
            <div className="theme-panel">
              <div
                className="theme-preview"
                style={{ background: user.portalColor }}
              >
                <span>EJB</span>
                <h3>Tu portal, tu color</h3>
                <p>La selección se guarda en tu perfil.</p>
              </div>
              <div>
                <h3>Color principal</h3>
                <p>Elige una opción o utiliza el selector.</p>
                <div className="swatches">
                  {[
                    "#0B2347",
                    "#123A70",
                    "#1D4ED8",
                    "#0F4C5C",
                    "#4C1D95",
                    "#7C2D12",
                  ].map((c) => (
                    <button
                      key={c}
                      style={{ background: c }}
                      className={user.portalColor === c ? "selected" : ""}
                      onClick={() => changeColor(c)}
                      aria-label={c}
                    />
                  ))}
                </div>
                <label className="color-picker">
                  Color personalizado
                  <input
                    type="color"
                    value={user.portalColor}
                    onChange={(e) => changeColor(e.target.value)}
                  />
                  <b>{user.portalColor}</b>
                </label>
              </div>
            </div>
          )}
        </section>
        </div>
      </main>
      {modal && (
        <div className="overlay">
          <form className="modal" onSubmit={addInitiative}>
            <button
              type="button"
              className="close"
              onClick={() => setModal(false)}
            >
              <X />
            </button>
            <div className="modal-icon">
              <Lightbulb />
            </div>
            <h2>Nueva iniciativa</h2>
            <p>Se registrará inicialmente como Pendiente.</p>
            <label>
              Título
              <input name="titulo" required minLength={3} />
            </label>
            <label>
              Descripción
              <textarea name="descripcion" required minLength={10} />
            </label>
            <div className="form-grid">
              <label>
                Área
                <select name="area">
                  {areas.map((a) => (
                    <option key={a.id}>{a.nombre}</option>
                  ))}
                </select>
              </label>
              <label>
                Impacto
                <input
                  name="impacto"
                  type="number"
                  min="1"
                  max="10"
                  defaultValue="7"
                />
              </label>
              <label>
                Esfuerzo
                <select name="esfuerzo">
                  <option>Bajo</option>
                  <option>Medio</option>
                  <option>Alto</option>
                </select>
              </label>
            </div>
            <div className="two-fields schedule-fields">
              <label>
                Fecha de inicio
                <input name="fechaInicio" type="date" />
              </label>
              <label>
                Fecha estimada de fin
                <input name="fechaFin" type="date" />
              </label>
            </div>
            <div className="modal-actions">
              <label className="initiative-tasks-field">
                Tareas por agregar
                <textarea name="tareas" placeholder={"Una tarea por línea\nEj. Preparar propuesta\nEj. Validar con Gerencia"} />
                <small>Podrás marcarlas y comentarlas desde el detalle del proyecto.</small>
              </label>
              <button type="button" onClick={() => setModal(false)}>
                Cancelar
              </button>
              <button className="primary">
                Registrar
                <ArrowRight />
              </button>
            </div>
          </form>
        </div>
      )}
      {progressItem && (
        <div className="overlay">
          <div className="progress-modal">
            <button className="close" onClick={() => setProgressItem(null)}>
              <X />
            </button>
            <div className="modal-icon">
              <TrendingUp />
            </div>
            <h2>Progreso · {progressItem.codigo}</h2>
            <p>{progressItem.titulo}</p>
            <form onSubmit={addProgress}>
              <label>
                Porcentaje de avance <b>{progressItem.avance}% actual</b>
                <input
                  name="porcentaje"
                  type="range"
                  min="0"
                  max="100"
                  defaultValue={progressItem.avance}
                />
              </label>
              <label>
                Comentario
                <textarea
                  name="comentario"
                  required
                  minLength={3}
                  placeholder="Describe qué se completó y el siguiente paso"
                />
              </label>
              <button className="primary">Guardar progreso</button>
            </form>
            <h3>Historial</h3>
            <div className="history">
              {history.map((h) => (
                <article key={h.id}>
                  <div>
                    <Clock3 />
                    <b>{h.porcentaje}%</b>
                  </div>
                  <p>{h.comentario}</p>
                  <small>
                    {h.usuario.nombres} {h.usuario.apellidos} ·{" "}
                    {new Date(h.createdAt).toLocaleString()}
                  </small>
                </article>
              ))}
              {!history.length && <span>Sin actualizaciones todavía.</span>}
            </div>
          </div>
        </div>
      )}
      {appearanceItem && <AppearanceModal item={appearanceItem} onClose={()=>setAppearanceItem(null)} onSave={async(icono,colorIcono)=>{const saved=await saveInitiativeAppearance(appearanceItem.id,{icono,colorIcono});setItems((rows)=>rows.map((row)=>row.id===appearanceItem.id?mapItem(saved):row));setAppearanceItem(null);setToast("Apariencia actualizada");}} />}
      {selectedItem && <div className="overlay"><section className="initiative-detail"><button className="close" onClick={()=>setSelectedItem(null)}><X/></button><div className="detail-head"><div className="area-icon" style={{background:selectedItem.colorIcono??selectedItem.color,color:readableText(selectedItem.colorIcono??selectedItem.color)}}>{selectedItem.icono??selectedItem.area[0]}</div><div><small>{selectedItem.area} · {selectedItem.codigo}</small><h2>{selectedItem.titulo}</h2></div></div><p>{selectedItem.descripcion}</p><div className="detail-stats"><div><span>Estado</span><b>{selectedItem.estado}</b></div><div><span>Score</span><b>{selectedItem.score}</b></div><div><span>Esfuerzo</span><b>{selectedItem.esfuerzo}</b></div><div><span>Avance</span><b>{selectedItem.avance}%</b></div></div><div className="detail-progress"><i style={{width:`${selectedItem.avance}%`}}/></div><div className="detail-dates"><span>Inicio: {selectedItem.fechaInicio?new Date(selectedItem.fechaInicio).toLocaleDateString():"Sin fecha"}</span><span>Fin: {selectedItem.fechaFin?new Date(selectedItem.fechaFin).toLocaleDateString():"Sin fecha"}</span></div><InitiativeTasks item={selectedItem} onUpdate={updated=>{setSelectedItem(updated);setItems(rows=>rows.map(row=>row.id===updated.id?updated:row))}}/><button className="primary" onClick={()=>{setSelectedItem(null);openProgress(selectedItem)}}><TrendingUp/>Registrar progreso</button></section></div>}
      {helpTopic && <div className="overlay"><section className="help-modal"><button className="close" onClick={()=>setHelpTopic(null)}><X/></button><div className="modal-icon"><CircleHelp/></div><h2>{helpTopic.title}</h2><p>{helpTopic.detail}</p><button className="primary" onClick={()=>setHelpTopic(null)}>Entendido</button></section></div>}
      {messageNotice&&<button className="message-notice" onClick={()=>{setPage("mensajes");setMessageNotice(null)}}>{messageNotice.photo?<img src={messageNotice.photo}/>:<span><MessageCircle/></span>}<div><b>{messageNotice.name}</b><p>{messageNotice.message}</p></div></button>}
      {toast && <div className="toast">✓ {toast}</div>}
    </div>
  );
}
function InitiativeTasks({item,onUpdate}:{item:Item;onUpdate:(item:Item)=>void}){
  const saveTask=async(task:Item["tareas"][number],estado:string)=>{
    const completing=estado==="Completada";
    const comentario=await uiPrompt(completing?"Completar tarea":"Actualizar tarea",task.comentario??"",{message:completing?"Describe brevemente qué se completó.":"Añade un comentario sobre el cambio.",multiline:true});
    if(completing&&!comentario)return;
    const saved=await updateInitiativeTask(item.id,task.id,{estado,comentario:comentario||undefined});
    onUpdate({...item,tareas:item.tareas.map(row=>row.id===task.id?saved:row)});
  };
  const add=async(e:FormEvent<HTMLFormElement>)=>{e.preventDefault();const form=e.currentTarget,title=String(new FormData(form).get("titulo")||"").trim();if(!title)return;const saved=await addInitiativeTask(item.id,{titulo:title});onUpdate({...item,tareas:[...item.tareas,saved]});form.reset()};
  return <section className="initiative-tasks"><div className="tasks-heading"><div><h3>Checklist de tareas</h3><p>{item.tareas.filter(task=>task.completada).length} de {item.tareas.length} completadas</p></div><span>{item.tareas.length?Math.round(item.tareas.filter(task=>task.completada).length/item.tareas.length*100):0}%</span></div><div className="tasks-progress"><i style={{width:`${item.tareas.length?item.tareas.filter(task=>task.completada).length/item.tareas.length*100:0}%`}}/></div><div className="task-list">{item.tareas.map(task=><article className={task.completada?"completed":""} key={task.id}><button className="task-check" onClick={()=>saveTask(task,task.completada?"Pendiente":"Completada")} aria-label={task.completada?"Reabrir tarea":"Completar tarea"}>{task.completada?"✓":""}</button><div><b>{task.titulo}</b>{task.comentario&&<small>{task.comentario}</small>}</div><select className={`task-status ${task.estado.toLowerCase().replace("_","-")}`} value={task.estado} onChange={e=>saveTask(task,e.target.value)}><option value="Pendiente">Pendiente</option><option value="Iniciado">Iniciado</option><option value="En_progreso">En progreso</option><option value="Completada">Completada</option></select></article>)}{!item.tareas.length&&<p className="tasks-empty">Aún no hay tareas para esta iniciativa.</p>}</div><form className="add-task" onSubmit={add}><input name="titulo" placeholder="Agregar una nueva tarea" required minLength={2}/><button>Agregar</button></form></section>;
}
function SectionTools({
  areas,
  area,
  setArea,
  open,setOpen,status,setStatus,effort,setEffort,sort,setSort,
}: {
  areas: Area[];
  area: string;
  setArea: (a: string) => void;
  open:boolean;setOpen:(v:boolean)=>void;status:string;setStatus:(v:string)=>void;effort:string;setEffort:(v:string)=>void;sort:string;setSort:(v:string)=>void;
}) {
  return (
    <div className="filters">
      <select value={area} onChange={(e) => setArea(e.target.value)}>
        <option>Todas</option>
        {areas.map((a) => (
          <option key={a.id}>{a.nombre}</option>
        ))}
      </select>
      <button className={open?"active":""} onClick={()=>setOpen(!open)}>
        <SlidersHorizontal />
        Filtros
      </button>
      {open && <div className="filter-popover"><label>Estado<select value={status} onChange={(e)=>setStatus(e.target.value)}><option>Todos</option><option>Pendiente</option><option>En evaluación</option><option>Priorizado</option><option>En desarrollo</option></select></label><label>Esfuerzo<select value={effort} onChange={(e)=>setEffort(e.target.value)}><option>Todos</option><option>Bajo</option><option>Medio</option><option>Alto</option></select></label><label>Ordenar<select value={sort} onChange={(e)=>setSort(e.target.value)}><option value="score">Mayor score</option><option value="avance">Mayor avance</option><option value="recientes">Más recientes</option></select></label><button onClick={()=>{setStatus("Todos");setEffort("Todos");setSort("score");setArea("Todas")}}>Limpiar filtros</button></div>}
    </div>
  );
}
function Help({ title, text, detail, onOpen }: HelpTopic & {onOpen:(topic:HelpTopic)=>void}) {
  return (
    <button className="help-card" onClick={()=>onOpen({title,text,detail})}>
      <div>
        <CircleHelp />
      </div>
      <h3>{title}</h3>
      <p>{text}</p>
      <span>Ver explicación <ArrowRight/></span>
    </button>
  );
}

function AppearanceModal({item,onClose,onSave}:{item:Item;onClose:()=>void;onSave:(icono:string,color:string)=>void}){
  const [icono,setIcono]=useState(item.icono??item.area[0]),[color,setColor]=useState(item.colorIcono??item.color);
  return <div className="overlay"><section className="appearance-modal"><button className="close" onClick={onClose}><X/></button><h2>Personalizar iniciativa</h2><p>Elige un emoji o escribe hasta dos iniciales.</p><div className="appearance-preview" style={{background:color,color:readableText(color)}}>{icono}</div><div className="emoji-options">{["💡","🚀","📊","🎯","⚙️","📣","💼","✨"].map((e)=><button key={e} className={icono===e?"selected":""} onClick={()=>setIcono(e)}>{e}</button>)}</div><label>Iniciales o emoji<input value={icono} maxLength={12} onChange={(e)=>setIcono(e.target.value)}/></label><label>Color del icono<div className="visual-color"><input type="color" value={color} onChange={(e)=>setColor(e.target.value)}/><span style={{background:color}}/><b>{color.toUpperCase()}</b></div></label><div className="modal-actions"><button onClick={onClose}>Cancelar</button><button className="primary" onClick={()=>onSave(icono,color)}>Guardar</button></div></section></div>
}
export default App;
