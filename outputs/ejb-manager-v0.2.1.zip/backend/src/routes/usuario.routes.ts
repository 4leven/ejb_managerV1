import { Router } from 'express';
import { catalog,color,password,preferences,profile,removeTeamMember,team,teamCargo } from '../controllers/usuario.controller.js';
import { requireAuth } from '../middlewares/auth.js';
export const usuarioRoutes=Router().get('/catalogo',catalog).get('/equipo',requireAuth,team).patch('/equipo/:id/cargo',requireAuth,teamCargo).delete('/equipo/:id',requireAuth,removeTeamMember).patch('/me/color',requireAuth,color).patch('/me/preferencias',requireAuth,preferences).patch('/me/perfil',requireAuth,profile).patch('/me/password',requireAuth,password);
