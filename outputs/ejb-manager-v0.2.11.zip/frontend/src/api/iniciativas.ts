export const API_URL=import.meta.env.VITE_API_URL??`http://${window.location.hostname}:4000/api`;
const authHeaders=()=>({Authorization:`Bearer ${localStorage.getItem('ejb_token')??''}`});
export async function fetchIniciativas(){const r=await fetch(`${API_URL}/iniciativas`,{headers:authHeaders()});if(!r.ok)throw new Error('No se pudo conectar');return r.json()}
export async function fetchCatalogo(){const r=await fetch(`${API_URL}/usuarios/catalogo`);if(!r.ok)throw new Error('No se pudo cargar el catálogo');return r.json()}
export async function createIniciativa(data:{titulo:string;descripcion:string;areaId:string;impacto:number;esfuerzo:string;fechaInicio?:string;fechaFin?:string;tareas?:string[]}){const r=await fetch(`${API_URL}/iniciativas`,{method:'POST',headers:{'Content-Type':'application/json',...authHeaders()},body:JSON.stringify(data)});if(!r.ok){const error=await r.json().catch(()=>({}));throw new Error(error.message??'No se pudo registrar')}return r.json()}
export async function register(data:Record<string,string>){const r=await fetch(`${API_URL}/auth/registro`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});const body=await r.json();if(!r.ok)throw new Error(body.message??'No se pudo crear la cuenta');return body}
export async function login(email:string,password:string){const r=await fetch(`${API_URL}/auth/login`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email,password})});const body=await r.json();if(!r.ok)throw new Error(body.message??'No se pudo iniciar sesión');return body}
export async function me(){const r=await fetch(`${API_URL}/auth/me`,{headers:authHeaders()});if(!r.ok)throw new Error('Sesión inválida');return r.json()}
async function jsonRequest(path:string,options:RequestInit={}){const r=await fetch(`${API_URL}${path}`,{...options,headers:{'Content-Type':'application/json',...authHeaders(),...(options.headers??{})}});const body=await r.json();if(!r.ok)throw new Error(body.message??'No se pudo completar la operación');return body}
export const fetchObjetivos=()=>jsonRequest('/objetivos');
export const createObjetivo=(data:{nombre:string;descripcion:string})=>jsonRequest('/objetivos',{method:'POST',body:JSON.stringify(data)});
export const fetchEquipo=()=>jsonRequest('/usuarios/equipo');
export const saveTeamCargo=(id:string,cargo:string)=>jsonRequest(`/usuarios/equipo/${id}/cargo`,{method:'PATCH',body:JSON.stringify({cargo})});
export const deleteTeamMember=(id:string)=>jsonRequest(`/usuarios/equipo/${id}`,{method:'DELETE'});
export const savePortalColor=(portalColor:string)=>jsonRequest('/usuarios/me/color',{method:'PATCH',body:JSON.stringify({portalColor})});
export const fetchProgresos=(id:string)=>jsonRequest(`/iniciativas/${id}/progresos`);
export const addProgreso=(id:string,data:{porcentaje:number;comentario:string})=>jsonRequest(`/iniciativas/${id}/progresos`,{method:'POST',body:JSON.stringify(data)});
export const addInitiativeTask=(id:string,data:{titulo:string;estado?:string})=>jsonRequest(`/iniciativas/${id}/tareas`,{method:'POST',body:JSON.stringify(data)});
export const updateInitiativeTask=(id:string,taskId:string,data:{estado:string;comentario?:string})=>jsonRequest(`/iniciativas/${id}/tareas/${taskId}`,{method:'PATCH',body:JSON.stringify(data)});
export const saveInitiativeAppearance=(id:string,data:{icono:string;colorIcono:string})=>jsonRequest(`/iniciativas/${id}/apariencia`,{method:'PATCH',body:JSON.stringify(data)});
export const updateInitiative=(id:string,data:{titulo:string;descripcion:string;areaId:string})=>jsonRequest(`/iniciativas/${id}`,{method:'PATCH',body:JSON.stringify(data)});
export const deleteInitiative=(id:string)=>jsonRequest(`/iniciativas/${id}`,{method:'DELETE'});
export const fetchConversations=()=>jsonRequest('/mensajes/conversaciones');
export const saveMessageStatus=(estadoMensaje:string)=>jsonRequest('/usuarios/me/estado-mensaje',{method:'PATCH',body:JSON.stringify({estadoMensaje})});
export const fetchMessages=(userId:string)=>jsonRequest(`/mensajes/${userId}`);
export const sendMessage=(userId:string,data:string|Record<string,unknown>)=>jsonRequest(`/mensajes/${userId}`,{method:'POST',body:JSON.stringify(typeof data==='string'?{contenido:data}:data)});
export const fetchAlerts=()=>jsonRequest('/alertas');
export const fetchEvents=()=>jsonRequest('/eventos');
export const createEvent=(data:Record<string,unknown>)=>jsonRequest('/eventos',{method:'POST',body:JSON.stringify(data)});
export const updateEvent=(id:string,data:Record<string,unknown>)=>jsonRequest(`/eventos/${id}`,{method:'PATCH',body:JSON.stringify(data)});
export const deleteEvent=(id:string)=>jsonRequest(`/eventos/${id}`,{method:'DELETE'});
export const fetchApprovals=()=>jsonRequest('/aprobaciones');
export const requestChange=(data:Record<string,unknown>)=>jsonRequest('/aprobaciones',{method:'POST',body:JSON.stringify(data)});
export const resolveApproval=(id:string,approved:boolean)=>jsonRequest(`/aprobaciones/${id}/resolver`,{method:'POST',body:JSON.stringify({approved})});
export const savePreferences=(darkMode:boolean)=>jsonRequest('/usuarios/me/preferencias',{method:'PATCH',body:JSON.stringify({darkMode})});
export const saveProfile=(data:{nombres:string;apellidos:string;fotoPerfil?:string|null;cargo?:string;areaId?:string})=>jsonRequest('/usuarios/me/perfil',{method:'PATCH',body:JSON.stringify(data)});
export const changePassword=(currentPassword:string,newPassword:string)=>jsonRequest('/usuarios/me/password',{method:'PATCH',body:JSON.stringify({currentPassword,newPassword})});
export const fetchRequirements=()=>jsonRequest('/operacion/requerimientos');
export const createRequirement=(data:Record<string,unknown>)=>jsonRequest('/operacion/requerimientos',{method:'POST',body:JSON.stringify(data)});
export const updateRequirement=(id:string,data:Record<string,unknown>)=>jsonRequest(`/operacion/requerimientos/${id}`,{method:'PATCH',body:JSON.stringify(data)});
export const deleteRequirement=(id:string)=>jsonRequest(`/operacion/requerimientos/${id}`,{method:'DELETE'});
export const fetchFlows=()=>jsonRequest('/operacion/flujos');
export const createFlow=(data:Record<string,unknown>)=>jsonRequest('/operacion/flujos',{method:'POST',body:JSON.stringify(data)});
export const forgotPassword=(email:string)=>jsonRequest('/auth/olvide-password',{method:'POST',body:JSON.stringify({email})});
export const resetPassword=(token:string,password:string)=>jsonRequest('/auth/restablecer-password',{method:'POST',body:JSON.stringify({token,password})});
