import { NextFunction,Request,Response } from 'express';
import { z } from 'zod';
import { prisma } from '../config/db.js';
const schema=z.object({nombre:z.string().min(3).max(150),descripcion:z.string().max(1000).optional()});
export const list=async(_req:Request,res:Response,next:NextFunction)=>{try{res.json(await prisma.objetivoNegocio.findMany({include:{_count:{select:{iniciativas:true}}},orderBy:{createdAt:'desc'}}))}catch(e){next(e)}};
export const create=async(req:Request,res:Response,next:NextFunction)=>{try{res.status(201).json(await prisma.objetivoNegocio.create({data:schema.parse(req.body)}))}catch(e){next(e)}};
