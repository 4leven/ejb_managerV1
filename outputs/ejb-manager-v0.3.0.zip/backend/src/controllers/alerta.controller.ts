import { NextFunction, Request, Response } from "express";
import { prisma } from "../config/db.js";

export async function alerts(req: Request, res: Response, next: NextFunction) {
  try {
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const completedSince = new Date(now.getTime() - 7 * 86400000);
    const actor = await prisma.usuario.findUniqueOrThrow({ where: { id: req.userId! } });
    const initiatives = await prisma.iniciativa.findMany({
      where: actor.isSuperAdmin ? {} : { OR: [{ areaId: actor.areaId }, { responsableId: actor.id }] },
      include: {
        area: true,
        progresos: {
          orderBy: { createdAt: "desc" },
          take: 1,
          include: { usuario: { select: { nombres: true, apellidos: true } } },
        },
      },
    });

    res.json(initiatives.flatMap((initiative) => {
      const result: any[] = [];
      const latest = initiative.progresos[0];
      if (initiative.porcentajeAvance >= 100) {
        if (latest && latest.createdAt >= completedSince) {
          const author = `${latest.usuario.nombres} ${latest.usuario.apellidos}`.trim();
          result.push({ type: "completado", severity: "success", initiativeId: initiative.id, code: initiative.codigo, title: `${initiative.codigo} fue completada`, message: `Completada por ${author} · ${latest.createdAt.toLocaleString("es-PE")}` });
        }
        return result;
      }
      if (initiative.fechaFin && initiative.fechaFin < today) result.push({ type: "retraso", severity: "high", initiativeId: initiative.id, code: initiative.codigo, title: `${initiative.codigo} está retrasada`, message: `Fecha límite: ${initiative.fechaFin.toLocaleDateString("es-PE")}` });
      const lastProgress = latest?.createdAt;
      if (initiative.estado === "En_desarrollo" && (!lastProgress || lastProgress < today)) result.push({ type: "sin_avance", severity: "medium", initiativeId: initiative.id, code: initiative.codigo, title: `${initiative.codigo} sin avance diario`, message: "No se registró progreso hoy" });
      return result;
    }));
  } catch (error) {
    next(error);
  }
}
