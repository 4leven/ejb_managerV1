import { Router } from 'express';import { alerts } from '../controllers/alerta.controller.js';export const alertaRoutes=Router().get('/',alerts);
