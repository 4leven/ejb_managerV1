import { Router } from 'express';import { create,list } from '../controllers/objetivo.controller.js';
export const objetivoRoutes=Router().get('/',list).post('/',create);
